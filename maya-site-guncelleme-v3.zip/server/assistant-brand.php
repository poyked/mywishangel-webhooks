<?php
declare(strict_types=1);
function assistantBrandFacts(array $saved=[]):array{
 $defaults=['naturalIngredients'=>true,'noAdditives'=>true,'noPreservatives'=>true,'note'=>'Doğal içeriklerle hazırlanır. Katkı maddesi ve koruyucu kullanılmaz.'];
 return array_replace($defaults,array_intersect_key($saved,$defaults));
}
function assistantBrandReply(string $question,array $facts):?string{
 $q=trim(preg_replace('/\s+/u',' ',preg_replace('/[?!.,;:…]/u','',mb_strtolower($question,'UTF-8'))));
 $natural=in_array($q,['ürünleriniz doğal mı','peynirleriniz doğal mı','ürünler doğal mı','peynirler doğal mı','doğal mı','ürünleriniz doğal mıdır'],true);
 $additives=in_array($q,['katkı var mı','katkı maddesi var mı','ürünlerinizde katkı var mı','ürünlerinizde katkı maddesi var mı','peynirlerinizde katkı var mı','ürünleriniz katkısız mı','katkısız mı'],true);
 $preservatives=in_array($q,['koruyucu var mı','koruyucu içeriyor mu','ürünlerinizde koruyucu var mı','peynirlerinizde koruyucu var mı','ürünleriniz koruyucusuz mu'],true);
 if((!$natural&&!$additives&&!$preservatives)||($natural&&!$facts['naturalIngredients'])||($additives&&!$facts['noAdditives'])||($preservatives&&!$facts['noPreservatives']))return null;
 $parts=[];
 if($natural&&$facts['naturalIngredients'])$parts[]='Evet, Maya peynirlerini doğal içeriklerle hazırlıyoruz.';
 if($facts['noAdditives']&&$facts['noPreservatives'])$parts[]='Ürünlerimizde katkı maddesi ve koruyucu kullanmıyoruz.';
 elseif($additives&&$facts['noAdditives'])$parts[]='Maya peynirlerinde katkı maddesi kullanmıyoruz.';
 elseif($preservatives&&$facts['noPreservatives'])$parts[]='Maya peynirlerinde koruyucu kullanmıyoruz.';
 if(!$parts)return null;
 return implode(' ',$parts).' Dilerseniz sevdiğiniz peynirin içeriğine birlikte bakalım; beyaz peynir mi, kaşar mı tercih edersiniz?';
}
