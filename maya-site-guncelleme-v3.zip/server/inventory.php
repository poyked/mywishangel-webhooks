<?php
declare(strict_types=1);
function inventoryCounts(array $products,array $orders):array{
 $reserved=[];$byWeight=[];foreach($orders as $o){if(!in_array($o['payment_status']??'', ['pending','paid'],true)||in_array($o['status']??'', ['shipped','delivered','cancelled','payment_failed'],true))continue;
 foreach(json_decode((string)($o['items_json']??'[]'),true)?:[] as $line){$id=(string)($line['id']??'');$qty=max(0,(int)($line['qty']??0));$weight=(int)($line['weight']??0);$reserved[$id]=($reserved[$id]??0)+$qty;$byWeight[$id][$weight]=($byWeight[$id][$weight]??0)+$qty;}}
 $result=[];foreach($products as $p){$id=$p['id'];$available=(int)($p['stock']??0);$qty=$reserved[$id]??0;$variants=[];foreach($p['variants']??[] as $v){$n=$byWeight[$id][(int)$v['weight']]??0;$variants[]=['weight'=>(int)$v['weight'],'available'=>(int)$v['stock'],'reserved'=>$n,'onHand'=>(int)$v['stock']+$n];}
 $result[$id]=['available'=>$available,'reserved'=>$qty,'onHand'=>$available+$qty,'variants'=>$variants];}return $result;
}
function inventorySnapshot():array{return inventoryCounts(records('products'),sql("SELECT status,payment_status,items_json FROM orders WHERE payment_status IN ('pending','paid') AND status NOT IN ('shipped','delivered','cancelled','payment_failed')")->fetchAll());}
function orderTransitionAllowed(string $from,string $to):bool{return $from===$to||in_array($to,['preparing'=>['ready','shipped'],'ready'=>['shipped'],'shipped'=>['delivered'],'delivered'=>[]][$from]??[],true);}
