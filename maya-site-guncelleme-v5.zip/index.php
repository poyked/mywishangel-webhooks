<?php
declare(strict_types=1);
ini_set('display_errors','0');
ob_start(function($html){return preg_replace_callback('~(assets/[a-zA-Z0-9_-]+\.(?:js|css))~',fn($m)=>$m[1].'?v='.(is_file(__DIR__.'/'.$m[1])?substr(hash_file('sha256',__DIR__.'/'.$m[1]),0,12):'1'),$html);});
try{require __DIR__.'/server/bootstrap.php';startSession();[$route,$routeId]=resolveStoreRoute();$_GET['p']=$route;$_GET['id']=$routeId;$store=publicStore();}catch(Throwable $e){http_response_code(503);echo 'Mağaza bağlantısı şu anda hazırlanıyor. Lütfen daha sonra tekrar deneyin.';exit;}
$template=file_get_contents(__DIR__.'/server/store-template.html');
require __DIR__.'/server/seo.php';$seo=seoPage($store);
$seoImages=preg_replace_callback('~<img src="assets/(images/uploads/[A-Za-z0-9_.-]+\.(?:webp|png|jpe?g))"([^>]*)>~',function($m)use($route){$u=fn($w)=>'image.php?src='.rawurlencode($m[1]).'&amp;w='.$w;$rest=str_replace(' loading="lazy"','',$m[2]);if($route==='urun')return '<img class="product-main-image" src="'.$u(960).'" srcset="'.$u(640).' 640w, '.$u(960).' 960w, '.$u(1440).' 1440w" sizes="(max-width: 760px) 100vw, 50vw"'.$rest.' fetchpriority="high" decoding="async">';return '<img class="" src="'.$u(640).'" srcset="'.$u(320).' 320w, '.$u(480).' 480w, '.$u(640).' 640w, '.$u(960).' 960w" sizes="(max-width: 760px) 50vw, 25vw"'.$rest.' loading="lazy" decoding="async">';},$seo['body']);if(is_string($seoImages))$seo['body']=$seoImages;
$template=preg_replace('~<title>.*?</title>~s','<title>'.h($seo['title']).'</title>',$template);
$template=preg_replace('~<meta name="description" content="[^"]*">~','<meta name="description" content="'.h($seo['description']).'">',$template);
$template=str_replace('<head>','<head><base href="'.h(rtrim(envv('APP_URL'),'/').'/').'">',$template);
$template=str_replace('</head>',$seo['head'].'</head>',$template);
$template=str_replace('<div id="app"></div>','<div id="app">'.$seo['body'].'</div>',$template);
$payload='<script>window.MAYA_CATALOG='.json_encode($store['products'],JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).';window.MAYA_DEFAULTS='.json_encode($store['settings'],JSON_UNESCAPED_UNICODE|JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).';window.MAYA_SERVER='.json_encode(['route'=>$route.($routeId!==''?'/'.$routeId:''),'routePaths'=>routePaths(),'basePath'=>siteBasePath(),'customer'=>$store['customer'],'csrf'=>$store['csrf'],'googleClientId'=>$store['googleClientId'],'googleNonce'=>$store['googleNonce'],'categories'=>$store['categories'],'pages'=>$store['pages'],'campaigns'=>$store['campaigns'],'popups'=>$store['popups'],'crossSell'=>$store['crossSell'],'membership'=>$store['membership']],JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE).';</script>';
$template=str_replace('<script src="assets/data.js"></script>',$payload,$template);
$template=str_replace('<meta name="robots" content="noindex,nofollow">',siteIndexable()&&!$seo['noindex']?'':'<meta name="robots" content="noindex,nofollow">',$template);
header('X-Content-Type-Options: nosniff');header('Referrer-Policy: same-origin');header('Cache-Control: no-store');echo $template;
