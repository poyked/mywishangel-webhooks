<?php
declare(strict_types=1);
function collectionHeadingSettings(array $input,bool $strict=false):array{
 $result=['background'=>'','image'=>'','textColor'=>'','overlay'=>40,'position'=>'center'];
 foreach(['background','textColor'] as $key){$value=trim((string)($input[$key]??''));if($value!==''&&!preg_match('/^#[a-fA-F0-9]{6}$/',$value)){if($strict)throw new DomainException('Başlık bandı renk kodunu kontrol edin.');$value='';}$result[$key]=$value;}
 $image=trim((string)($input['image']??''));if($image!==''&&(!preg_match('~^images/[\pL\pM\pN_./-]+\.(webp|png|jpe?g)$~u',$image)||str_contains($image,'..'))){if($strict)throw new DomainException('Başlık arka planını görsel kütüphanesinden seçin.');$image='';}$result['image']=$image;
 $overlay=$input['overlay']??40;if(!is_numeric($overlay)||(float)$overlay<0||(float)$overlay>80){if($strict)throw new DomainException('Görsel karartması 0 ile 80 arasında olmalı.');$overlay=40;}$result['overlay']=(int)$overlay;
 $position=(string)($input['position']??'center');if(!in_array($position,['top','center','bottom'],true)){if($strict)throw new DomainException('Başlık görselinin kadrajını kontrol edin.');$position='center';}$result['position']=$position;return $result;
}
function collectionPageSettings(array $saved,array $products=[]):array{
 $defaults=['title'=>'Kahvaltı Seçkileri','eyebrow'=>'MAYA İLE KAHVALTI','body'=>'Damak zevkinize uygun peynirleri, seçkileri ve paketleri keşfedin.','sections'=>[['title'=>'Kahvaltınızı birlikte hazırlayalım.','body'=>'Peynirleri tanıyın, sevdiğiniz çeşitleri seçin.','image'=>'images/sofra.webp','imageSide'=>'left','columns'=>'auto','enabled'=>true,'products'=>array_slice(array_column(array_filter($products,fn($p)=>$p['active']??true),'id'),0,6)]]];
 $result=array_replace($defaults,array_intersect_key($saved,$defaults));$result['heading']=collectionHeadingSettings(is_array($saved['heading']??null)?$saved['heading']:[]);return $result;
}
function bundleFromSection(array $section,array $products,int $maxQuantity=20):?array{
 if(($section['enabled']??true)===false||($section['mode']??'bundle')!=='bundle'||empty($section['id']))return null;
 $lookup=array_column($products,null,'id');$items=$section['items']??[];if(!$items)foreach($section['products']??[] as $id){$p=$lookup[$id]??null;if($p)$items[]=['id'=>$id,'weight'=>(int)($p['weights'][0]??500),'qty'=>1];}
 if(!$items)return null;$members=[];$sale=0;$regular=0;$required=[];$stocks=[];
 foreach($items as $x){$p=$lookup[$x['id']??'']??null;$w=(int)($x['weight']??0);$qty=(int)($x['qty']??0);if(!$p||!($p['active']??false)||$qty<1||$qty>$maxQuantity||!in_array($w,$p['weights']??[],true))return null;$variant=null;foreach($p['variants']??[] as $v)if((int)$v['weight']===$w)$variant=$v;
  $unit=$variant?(int)round((float)$variant['price']*100):(int)round((float)$p['price']*$w/500*100);$old=$variant?(int)round((float)($variant['compareAt']??0)*100):(int)round((float)($p['compareAt']??0)*$w/500*100);if($unit<=0)return null;$old=max($unit,$old);$sale+=$unit*$qty;$regular+=$old*$qty;$key=$variant?$p['id'].'|'.$w:$p['id'];$required[$key]=($required[$key]??0)+$qty;$stocks[$key]=(int)($variant['stock']??$p['stock']??0);
  $members[]=['id'=>$p['id'],'name'=>$p['name'],'weight'=>$w,'qty'=>$qty,'unit'=>$unit,'regularUnit'=>$old,'image'=>$p['image']??'','description'=>$p['description']??'','ingredients'=>$p['ingredients']??'','allergens'=>$p['allergens']??'','storage'=>$p['storage']??''];
 }
 $type=$section['discountType']??'none';$value=max(0,(float)($section['discountValue']??0));$discount=$type==='percent'?(int)round($sale*min(100,$value)/100):($type==='fixed'?(int)round($value*100):0);$discount=min($sale,$discount);$available=PHP_INT_MAX;foreach($required as $key=>$qty)$available=min($available,intdiv(max(0,$stocks[$key]),$qty));
 return ['id'=>$section['id'],'slug'=>$section['slug']??$section['id'],'name'=>$section['title'],'description'=>$section['body']??'','image'=>$section['image']??'','gallery'=>$section['gallery']??[],'items'=>$members,'salesTotal'=>$sale,'regularTotal'=>$regular,'packageDiscount'=>$discount,'total'=>$sale-$discount,'available'=>$available===PHP_INT_MAX?0:$available,'active'=>true];
}
function storeBundles(?array $settings=null,?array $products=null):array{
 $settings??=record('settings','store')??[];$products??=records('products');$result=[];foreach($settings['collections']['sections']??[] as $s){$b=bundleFromSection($s,$products);if($b)$result[$b['id']]=$b;}return $result;
}
function findStoreBundle(string $id):?array{foreach(storeBundles() as $b)if($b['id']===$id||$b['slug']===$id)return $b;return null;}
function packageLineDiscounts(array $lines,array $bundles):array{
 $groups=[];foreach($lines as $i=>$line)if(!empty($line['packageId']))$groups[$line['packageId']][]=$i;$discounts=[];$warnings=[];
 foreach($groups as $id=>$indexes){$b=$bundles[$id]??null;if(!$b)throw new DomainException('Sepetteki paket artık mevcut değil. Paket ürünlerini kaldırıp güncel paketi ekleyin.');$needs=[];foreach($b['items'] as $x){$key=$x['id'].'|'.$x['weight'];$needs[$key]=($needs[$key]??0)+$x['qty'];}$quantities=[];foreach($indexes as $i){$key=$lines[$i]['id'].'|'.$lines[$i]['weight'];if(!isset($needs[$key]))throw new DomainException('Paketin ürün veya gramajı değişmiş. Güncel paketi yeniden ekleyin.');$quantities[$key]=($quantities[$key]??0)+$lines[$i]['qty'];}$count=PHP_INT_MAX;foreach($needs as $key=>$qty)$count=min($count,intdiv($quantities[$key]??0,$qty));if($count<1){$warnings[]=$b['name'].' paketi tamamlanmadığı için paket indirimi uygulanmadı.';continue;}
  $remaining=[];foreach($needs as $key=>$qty)$remaining[$key]=$qty*$count;$bases=[];foreach($indexes as $i){$key=$lines[$i]['id'].'|'.$lines[$i]['weight'];$qty=min($remaining[$key],$lines[$i]['qty']);$remaining[$key]-=$qty;if($qty>0)$bases[$i]=$qty*$lines[$i]['unit'];}$total=array_sum($bases);$amount=min($total,$b['packageDiscount']*$count);if(!$amount)continue;$parts=[];$fractions=[];$allocated=0;foreach($bases as $i=>$base){$share=$amount*($base/$total);$parts[$i]=(int)floor($share);$fractions[$i]=$share-$parts[$i];$allocated+=$parts[$i];}arsort($fractions);$left=$amount-$allocated;foreach($fractions as $i=>$fraction){if($left<=0)break;if($parts[$i]<$bases[$i]){$parts[$i]++;$left--;}}foreach($parts as $i=>$value)$discounts[$i]=($discounts[$i]??0)+$value;
 }
 return ['byLine'=>$discounts,'total'=>array_sum($discounts),'warnings'=>$warnings];
}
