<?php
declare(strict_types=1);
require __DIR__.'/server/bootstrap.php';
header('X-Content-Type-Options: nosniff');header('Cache-Control: no-cache');$type=(string)($_GET['type']??'sitemap');$map=['sitemap'=>'sitemap.xml','robots'=>'robots.txt','llm'=>'llm.txt','llms'=>'llms.txt','llms-en'=>'llms-en.txt','llms-tr'=>'llms-tr.txt','llms-full'=>'llms-full.txt'];if(!isset($map[$type])){http_response_code(404);exit;}$documents=discoveryDocuments(discoverySnapshot(),rtrim(envv('APP_URL'),'/'),siteIndexable());header('Content-Type: '.($type==='sitemap'?'application/xml':'text/plain').'; charset=utf-8');if(!siteIndexable())header('X-Robots-Tag: noindex, nofollow');echo $documents[$map[$type]];
