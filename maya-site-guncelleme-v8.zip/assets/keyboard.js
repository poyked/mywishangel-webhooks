// Explicit submission keeps password-eye buttons from affecting Enter behavior.
document.addEventListener('keydown',event=>{
 if(event.key!=='Enter'||event.isComposing||event.keyCode===229||event.shiftKey||event.ctrlKey||event.altKey||event.metaKey)return;
 const input=event.target,form=input.form;if(!form||input.disabled)return;
 const account=['login-form','admin-login-form','register-form','forgot-form','reset-form','account-form','admin-password-form'].includes(form.id)&&input.tagName==='INPUT'&&!['checkbox','radio','file','submit','button'].includes(input.type);
 const question=(form.id==='ask-form'&&input.id==='ask-input')||(form.id==='admin-ai-form'&&input.name==='question');
 if(!account&&!question)return;
 event.preventDefault();
 const submit=[...form.querySelectorAll('button,input[type=submit]')].find(button=>button.type==='submit');
 if(submit?.disabled)return;
 if(submit)form.requestSubmit(submit);else form.requestSubmit();
},true);
