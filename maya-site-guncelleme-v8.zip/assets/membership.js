function googleBrandIcon(){
  return '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="#4285F4" d="M21.6 12.23c0-.71-.06-1.39-.18-2.05H12v3.88h5.38a4.6 4.6 0 0 1-1.99 3.02v2.51h3.23c1.89-1.74 2.98-4.3 2.98-7.36Z"/><path fill="#34A853" d="M12 22c2.7 0 4.96-.9 6.62-2.41l-3.23-2.51c-.9.6-2.05.96-3.39.96-2.6 0-4.81-1.76-5.6-4.12H3.06v2.59A10 10 0 0 0 12 22Z"/><path fill="#FBBC05" d="M6.4 13.92A6 6 0 0 1 6.08 12c0-.67.12-1.32.32-1.92V7.49H3.06A10 10 0 0 0 2 12c0 1.61.39 3.14 1.06 4.51l3.34-2.59Z"/><path fill="#EA4335" d="M12 5.96c1.47 0 2.79.5 3.83 1.51l2.87-2.87A9.6 9.6 0 0 0 12 2a10 10 0 0 0-8.94 5.49l3.34 2.59C7.19 7.72 9.4 5.96 12 5.96Z"/></svg>';
}

function eyeIcon(open = true){
  if(open){
    return '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
  }
  return '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" y1="2" x2="22" y2="22"/></svg>';
}

function membershipCheckboxes(){
  return `<div class="membership-acceptances">
    <label class="checkbox">
      <input type="checkbox" name="termsAccepted" required>
      <span><a href="${storeUrl('kullanim-kosullari')}" data-legal-modal="kullanim-kosullari" class="legal-doc-link">Kullanım koşullarını</a> okudum ve kabul ediyorum.</span>
    </label>
    <label class="checkbox">
      <input type="checkbox" name="privacyRead" required>
      <span><a href="${storeUrl('kvkk-aydinlatma')}" data-legal-modal="kvkk-aydinlatma" class="legal-doc-link">KVKK Aydınlatma Metni’ni</a> okudum.</span>
    </label>
  </div>`;
}

function membershipPayload(form){
  const f=new FormData(form);
  return {
    termsAccepted:f.has('termsAccepted'),
    privacyRead:f.has('privacyRead'),
    termsVersion:MAYA_SERVER?.membership?.['kullanim-kosullari']?.version||'',
    privacyVersion:MAYA_SERVER?.membership?.['kvkk-aydinlatma']?.version||''
  };
}

function googleCompleteProfile(credential){
  drawer('Google ile yeni hesap aç',`<form id="google-profile-form">
    <p>Hesabınızı tamamlamak için iletişim bilgilerinizi ve metinleri kontrol edin.</p>
    <label>Ad soyad
      <input name="name" required autocomplete="name">
    </label>
    <label>Telefon numarası
      <div class="phone-dropdown-group">
        <div class="phone-country-dropdown">
          <select name="phoneCountry" aria-label="Ülke kodu">
            <option value="+90" selected>Türkiye (+90)</option>
          </select>
          <span class="dropdown-chevron" aria-hidden="true"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg></span>
        </div>
        <input name="phone" type="tel" inputmode="numeric" placeholder="532 123 45 67" required autocomplete="tel-national">
      </div>
    </label>
    <small class="form-helper-text">Ülke kodunu seçin, ardından telefon numaranızı yazın.</small>
    ${membershipCheckboxes()}
    <p id="google-profile-error" class="form-error" role="alert"></p>
    <button type="submit" class="btn full">Hesabımı oluştur</button>
  </form>`);
  document.querySelector('#google-profile-form')._credential=credential;
}

async function finishGoogle(credential,extra={}){
  const r=await serverApi('google-login',{credential,...extra});
  if(r.needsProfile){googleCompleteProfile(credential);return}
  MAYA_SERVER.csrf=r.csrf;MAYA_SERVER.customer=r.user;afterCustomerLogin();
}

document.addEventListener('click',e=>{
  const pwBtn=e.target.closest('[data-toggle-pw]');
  if(pwBtn){
    e.preventDefault();
    const wrapper=pwBtn.closest('.password-control, .password-input-wrapper');
    if(!wrapper)return;
    const input=wrapper.querySelector('input');
    if(!input)return;
    const isPw=input.type==='password';
    input.type=isPw?'text':'password';
    pwBtn.innerHTML=eyeIcon(!isPw);
    pwBtn.setAttribute('aria-label',isPw?'Şifreyi gizle':'Şifreyi göster');
    return;
  }
  const legalLink=e.target.closest('[data-legal-modal]');
  if(legalLink){
    if(e.ctrlKey||e.metaKey||e.button===1)return;
    e.preventDefault();
    const type=legalLink.dataset.legalModal;
    const page=window.MAYA_SERVER?.pages?.find(x=>x.id===type);
    const titles={'kullanim-kosullari':'Kullanım Koşulları','kvkk-aydinlatma':'KVKK Aydınlatma Metni','mesafeli-satis':'Mesafeli Satış Sözleşmesi','iptal-iade':'İptal ve İade Koşulları','cerez-politikasi':'Çerez Politikası'};
    const title=page?.title||titles[type]||'Bilgilendirme Metni';
    const content=page?.body?bodyParagraphs(page.body):'<p>Metin yükleniyor...</p>';
    drawer(title,`<div class="managed-body" style="font-size:15px;line-height:1.75;padding:10px 0">${content}</div>`);
  }
});

document.addEventListener('submit',async e=>{
  if(e.target.id!=='google-profile-form')return;
  e.preventDefault();
  const f=e.target;
  try{
    const rawData=Object.fromEntries(new FormData(f));
    const rawName=(rawData.name||'').trim();
    const parts=rawName.split(/\s+/);
    if(parts.length>1){
      rawData.surname=parts.pop();
      rawData.name=parts.join(' ');
    }else{
      rawData.surname=rawData.name;
    }
    await finishGoogle(f._credential,{...rawData,...membershipPayload(f)});
  }catch(err){
    f.querySelector('#google-profile-error').textContent=err.message;
  }
});
