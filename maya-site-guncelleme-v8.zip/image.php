<?php
declare(strict_types=1);
ini_set('display_errors','0');
$src=(string)($_GET['src']??'');$requested=max(240,min(1800,(int)($_GET['w']??960)));$width=1800;foreach([320,480,640,960,1440,1800] as $preset){if($requested<=$preset){$width=$preset;break;}}
if(!preg_match('~^images/[\pL\pN_./-]+\.(webp|png|jpe?g)$~u',$src)||str_contains($src,'..')){http_response_code(404);exit;}
$base=realpath(__DIR__.'/assets/images');$file=realpath(__DIR__.'/assets/'.$src);
if(!$file||!$base||!str_starts_with($file,$base.DIRECTORY_SEPARATOR)||!is_file($file)){http_response_code(404);exit;}
$storage=is_dir(__DIR__.'/server')?__DIR__.'/storage':dirname(__DIR__).'/storage';$folder=$storage.'/image-cache';
$size=@getimagesize($file);if(!$size||$size[0]*$size[1]>30000000){http_response_code(415);exit;}
if(!function_exists('imagewebp')){header('Content-Type: '.($size['mime']??'image/webp'));header('Cache-Control: public, max-age=604800');readfile($file);exit;}
if(!is_dir($folder)&&!@mkdir($folder,0755,true)){http_response_code(503);exit;}
$key=hash('sha256',$file.'|'.filemtime($file).'|'.$width.'|78');$cache=$folder.'/'.$key.'.webp';
if(!is_file($cache)){$im=@imagecreatefromstring(file_get_contents($file));if(!$im){http_response_code(415);exit;}$out=$im;if(imagesx($im)>$width){$out=imagescale($im,$width,(int)round(imagesy($im)*$width/imagesx($im)));}imagepalettetotruecolor($out);imagealphablending($out,false);imagesavealpha($out,true);$temp=$cache.'.'.bin2hex(random_bytes(5));if(!imagewebp($out,$temp,78)||!rename($temp,$cache)){http_response_code(503);exit;}}
header('Content-Type: image/webp');header('Cache-Control: public, max-age=604800');header('X-Content-Type-Options: nosniff');header('ETag: "'.$key.'"');if(($_SERVER['HTTP_IF_NONE_MATCH']??'')==='"'.$key.'"'){http_response_code(304);exit;}header('Content-Length: '.filesize($cache));readfile($cache);
