<?php
declare(strict_types=1);

function catalogPageDefaults():array{return [
 'title'=>'Ürünlerimiz','eyebrow'=>'MAYA PEYNİR','body'=>'Peynirlerimizi ve hazır paketlerimizi keşfedin. Damak zevkinize uygun ürünleri seçin.',
 'breadcrumb'=>'Ürünlerimiz','allLabel'=>'Tüm ürünler','supportTitle'=>'Seçerken aklınıza takılanlar?',
 'supportBody'=>'Ürün detaylarına göz atın veya bize sorun.','supportButton'=>'Alışveriş asistanını aç'
];}
function catalogPageSettings(array $input=[],bool $strict=false):array{
 $out=catalogPageDefaults();
 foreach(['title'=>250,'eyebrow'=>200,'body'=>4000,'breadcrumb'=>100,'allLabel'=>100,'supportTitle'=>250,'supportBody'=>2000,'supportButton'=>100] as $key=>$limit){
  if(!array_key_exists($key,$input))continue;
  if(!is_string($input[$key])){if($strict)throw new DomainException('Ürünlerimiz sayfasında metin alanını kontrol edin: '.$key);continue;}
  $value=trim($input[$key]);if(mb_strlen($value)>$limit){if($strict)throw new DomainException('Ürünlerimiz sayfasındaki '.$key.' alanı en fazla '.$limit.' karakter olabilir. Metin kesilmedi.');continue;}
  if(in_array($key,['title','breadcrumb','allLabel'],true)&&$value===''){if($strict)throw new DomainException('Sayfa başlığı, sayfa yolu adı ve tüm ürünler etiketi boş olamaz.');continue;}
  $out[$key]=$value;
 }
 return $out;
}

function managedSectionDefaults(string $id):array{
 if($id==='kurumsal')return ['heroEyebrow'=>'PROFESYONEL MUTFAKLAR İÇİN','heroButton'=>'Kurumsal iletişim ↗','editorialTitle'=>'İşletmenizin ihtiyaçlarına uygun.','editorialBody'=>'Otel, restoran ve profesyonel mutfaklar için ürün, gramaj ve teslimat planını birlikte değerlendirelim.','pillar1Title'=>'Ürün seçimi','pillar1Body'=>'Kahvaltı servisi ve sıcak mutfak kullanımına göre beyaz peynir ve kaşar seçeneklerini birlikte inceleyin.','pillar2Title'=>'İşletmenize uygun plan','pillar2Body'=>'Gramaj, sipariş miktarı ve teslimat beklentinizi bize iletin. Tedarik görüşmesini ihtiyaçlarınıza göre hazırlayalım.','pillar3Title'=>'Doğrudan iletişim','pillar3Body'=>'Ürün, numune veya düzenli tedarik taleplerinizi kurumsal formdan paylaşabilirsiniz.','contactEyebrow'=>'KURUMSAL İLETİŞİM','contactTitle'=>'Sizi dinliyoruz.'];
 if($id==='hikayemiz')return ['heroEyebrow'=>'MAYA PEYNİR','heroButton'=>'Ürünlerimizi keşfedin ↗','editorialTitle'=>'Üsküdar’dan bugünlere.','editorialBody'=>'1970’lerin başında Üsküdar’da başlayan peynir yolculuğumuz, bugün evlere ve profesyonel mutfaklara uzanıyor.','pillar1Title'=>'Tanışın.','pillar1Body'=>'Ürün açıklamalarını ve etiket bilgilerini inceleyin.','pillar2Title'=>'Keşfedin.','pillar2Body'=>'Kahvaltınız ve tarifleriniz için peynir çeşitlerine göz atın.','pillar3Title'=>'Konuşalım.','pillar3Body'=>'Tüketici ve kurumsal talepleriniz için bizimle iletişime geçin.'];return [];
}
function managedPageSettings(array $page,bool $strict=false):array{
 $defaults=managedSectionDefaults((string)($page['id']??''));if(!$defaults)return $page;
 $input=$page['sectionContent']??[];if(!is_array($input)){if($strict)throw new DomainException('Sayfa bölümlerini kontrol edin.');$input=[];}
 foreach($defaults as $key=>$fallback){if(!array_key_exists($key,$input))continue;$value=$input[$key];$limit=str_ends_with($key,'Body')?10000:300;if(!is_string($value)||mb_strlen($value)>$limit){if($strict)throw new DomainException('Sayfa bölümündeki '.$key.' alanı geçersiz veya çok uzun. Metin kesilmedi.');continue;}$defaults[$key]=trim($value);}
 $page['sectionContent']=$defaults;return $page;
}

function productLabelFields(array $input):array{
 foreach(['ingredients'=>20000,'allergens'=>4000,'storage'=>4000] as $key=>$maximum){$value=$input[$key]??'';if(!is_string($value)||mb_strlen($value)>$maximum)throw new DomainException('Ürünün '.$key.' alanı metin olmalı ve en fazla '.$maximum.' karakter içermeli. Metin kesilmedi.');$input[$key]=trim($value);}return $input;
}
