<?php
declare(strict_types=1);
if(PHP_SAPI!=='cli'){http_response_code(404);exit;}
require __DIR__.'/bootstrap.php';require __DIR__.'/mail.php';require __DIR__.'/customers.php';require __DIR__.'/marketing.php';
require __DIR__.'/insights.php';require __DIR__.'/ai.php';startSession();
$lock=fopen(APP_ROOT.'/storage/worker.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB))exit;
try{$run=runWorkerTasks(['trendyolOrders'=>fn()=>trendyolPollOrders(),'trendyolStock'=>fn()=>trendyolStockTick(),'trendyolProducts'=>fn()=>trendyolListingStatusTick(),'conversions'=>fn()=>processTrackingQueue(),'regularDelivery'=>fn()=>regularDeliveryTick(),'marketing'=>fn()=>marketingTick(),'mail'=>fn()=>processMailQueue(),'ai'=>fn()=>runAiJobs()]);echo jsonval($run).PHP_EOL;if($run['status']!=='complete')exit(1);}catch(Throwable $e){logError($e);fwrite(STDERR,"Görev tamamlanamadı. Sunucu kaydını kontrol edin.\n");exit(1);}finally{flock($lock,LOCK_UN);fclose($lock);}
