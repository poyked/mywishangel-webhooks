<?php
declare(strict_types=1);
function storeBranding(array $settings):array{
 $b=is_array($settings['branding']??null)?$settings['branding']:[];
 return ['logo'=>(string)($b['logo']??'images/maya-logo.webp'),'logoWidth'=>max(80,min(260,(int)($b['logoWidth']??138))),'mobileLogoWidth'=>max(70,min(180,(int)($b['mobileLogoWidth']??118)))];
}
function emailLogoUrl(array $branding):string{
 $path=(string)($branding['logo']??'');$base=rtrim(envv('APP_URL'),'/');if($path==='')return '';
 if(!preg_match('~^images/[\pL\pM\pN_./-]+\.(png|webp|jpe?g)$~u',$path)||str_contains($path,'..'))return '';
 if(defined('APP_ROOT')){
  $source=APP_ROOT.'/assets/'.$path;
  if(is_file($source)&&str_ends_with(strtolower($path),'.webp')&&function_exists('imagecreatefromwebp')&&function_exists('imagepng')){
   $name='mail-logo-'.substr(hash_file('sha256',$source),0,20).'.png';$folder=APP_ROOT.'/assets/images/email-logos';$target=$folder.'/'.$name;
   if(!is_file($target)){if(!is_dir($folder))@mkdir($folder,0755,true);$im=@imagecreatefromwebp($source);if($im){imagealphablending($im,false);imagesavealpha($im,true);$tmp=$folder.'/'.bin2hex(random_bytes(12)).'.png';if(imagepng($im,$tmp,6))rename($tmp,$target);imagedestroy($im);}}
   if(is_file($target))$path='images/email-logos/'.$name;
  }
  $file=APP_ROOT.'/assets/'.$path;if(is_file($file))return $base.'/assets/'.$path.'?v='.substr(hash_file('sha256',$file),0,12);
 }
 return $base.'/assets/'.$path;
}
function orderStatusLabel(string $status):string{return ['awaiting_payment'=>'Ödeme bekleniyor','payment_failed'=>'Ödeme başarısız','preparing'=>'Hazırlanıyor','ready'=>'Kargo hazırlandı','shipped'=>'Kargoya verildi','delivered'=>'Teslim edildi','cancelled'=>'İptal edildi'][$status]??$status;}
function notificationEmail(string $subject,string $body,string $eventKey='',?array $sampleOrder=null,?array $settingsOverride=null):string{
 $s=$settingsOverride??record('settings','store')??[];$brand=storeBranding($s);$email=is_array($s['emailBranding']??null)?$s['emailBranding']:[];
 $e=fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');$money=fn($v)=>number_format((int)$v/100,2,',','.').' TL';
 $primary=preg_match('/^#[a-fA-F0-9]{6}$/',(string)($s['primary']??''))?$s['primary']:'#233c32';$accent=preg_match('/^#[a-fA-F0-9]{6}$/',(string)($s['accent']??''))?$s['accent']:'#e4ac20';
 $business=trim((string)($email['name']??$s['contact']['business']??'Maya Peynir'))?:'Maya Peynir';$footer=trim((string)($email['footer']??'Ürünlerimiz ve siparişinizle ilgili sorularınızda yanınızdayız.'));
 $base=rtrim(envv('APP_URL'),'/');$order=$sampleOrder;
 if(!$order&&!str_starts_with($eventKey,'regular-')&&preg_match('/\bMAYA[0-9]{14}[a-f0-9]{16}\b/',$eventKey.' '.$body,$match))$order=sql('SELECT * FROM orders WHERE id=?',[$match[0]])->fetch()?:null;
 $details='';$buttonText='Mağazayı ziyaret edin';$buttonUrl=$base.'/';
 if($order){$items=json_decode((string)($order['items_json']??'[]'),true)?:[];$customer=json_decode((string)($order['customer_json']??'{}'),true)?:[];$tracking=json_decode((string)($order['tracking_json']??'{}'),true)?:[];
  $details=(orderIsTest($order)?'<p style="padding:14px;background:#fff0cc;color:#654719"><b>TEST SİPARİŞİ</b> — Gerçek tahsilat yapılmadı; fiziksel gönderim yapılmayacak.</p>':'').'<h2 style="font-size:20px;margin:28px 0 14px">Sipariş özeti</h2><p style="color:#697465;font-size:13px">'.$e(orderNumber($order)).' · '.$e(orderStatusLabel((string)$order['status'])).'</p><table role="presentation" width="100%" style="border-collapse:collapse;margin-top:16px">';
  foreach($items as $x){$amount=$x['lineTotal']??((int)($x['unit']??0)*(int)($x['qty']??0)-(int)($x['lineDiscount']??0));$details.='<tr><td style="padding:14px 0;border-bottom:1px solid #e5e8dd"><b>'.$e($x['name']??'Ürün').'</b><br><span style="font-size:12px;color:#697465">'.$e($x['weight']??'').' g · '.$e($x['qty']??0).' adet</span></td><td align="right" style="padding:14px 0;border-bottom:1px solid #e5e8dd;white-space:nowrap">'.$e($money($amount)).'</td></tr>';}
  $discount=(int)($customer['discount']??0);$details.='<tr><td style="padding-top:18px">Ara toplam</td><td align="right" style="padding-top:18px">'.$e($money($order['subtotal']??0)).'</td></tr>'.($discount?'<tr><td>İndirim</td><td align="right">−'.$e($money($discount)).'</td></tr>':'').'<tr><td>Kargo</td><td align="right">'.$e($money($order['shipping']??0)).'</td></tr><tr><td style="padding-top:14px;font-size:19px"><b>Toplam</b></td><td align="right" style="padding-top:14px;font-size:19px"><b>'.$e($money($order['total']??0)).'</b></td></tr></table>';
  if(!empty($tracking['carrier'])||!empty($tracking['number']))$details.='<div style="margin-top:24px;padding:18px;background:#f4f2e8;border-radius:8px"><b>Kargo bilgileri</b><p>'.$e($tracking['carrier']??'').' · '.$e($tracking['number']??'').'</p></div>';
  $buttonText='Sipariş takibi';$buttonUrl=routeUrl('takip');
 }elseif(preg_match('~https://[^\s<>"\x27]+~',$body,$match)){$buttonUrl=$match[0];$buttonText=str_starts_with($eventKey,'regular-due-')?'Size özel sepeti aç':(str_contains($eventKey,'reset-')?'Şifremi yenile':'Bağlantıyı aç');}
 $logo=$brand['logo']!==''?'<img src="'.$e(emailLogoUrl($brand)).'" alt="'.$e($business).'" width="'.min(200,$brand['logoWidth']).'" style="display:block;width:'.min(200,$brand['logoWidth']).'px;max-width:100%;height:auto;margin:0 auto;background:transparent">':'<b style="font-size:24px;color:'.$e($primary).'">'.$e($business).'</b>';
 return 'MAYA_HTML:<!doctype html><html lang="tr"><head><meta name="viewport" content="width=device-width,initial-scale=1"></head><body style="margin:0;background:#f3f1e8;color:#233c32;font-family:Arial,sans-serif"><table role="presentation" width="100%" style="background:#f3f1e8;padding:28px 12px"><tr><td align="center"><table role="presentation" width="600" style="width:100%;max-width:600px;background:#fffdf8;border-collapse:collapse"><tr><td align="center" style="padding:30px;border-bottom:4px solid '.$e($accent).'">'.$logo.'</td></tr><tr><td style="padding:32px 26px"><p style="font-size:11px;letter-spacing:2px;color:#9a782b;margin:0 0 14px">'.$e(mb_strtoupper($business,'UTF-8')).'</p><h1 style="font-size:27px;line-height:1.3;color:'.$e($primary).';margin:0 0 20px">'.$e($subject).'</h1><p style="font-size:15px;line-height:1.8">'.nl2br($e($body)).'</p>'.$details.'<p style="margin:28px 0 8px"><a href="'.$e($buttonUrl).'" style="display:inline-block;padding:15px 24px;background:'.$e($primary).';border-radius:6px;color:#fff;text-decoration:none;font-weight:bold">'.$e($buttonText).'</a></p></td></tr><tr><td style="padding:24px 26px;background:#e9eddf;font-size:12px;line-height:1.8;color:#62705c">'.$e($footer).'<br><a href="'.$e(routeUrl('iletisim')).'" style="color:'.$e($primary).'">İletişim</a> · <a href="'.$e(routeUrl('kvkk-aydinlatma')).'" style="color:'.$e($primary).'">Gizlilik ve KVKK</a></td></tr></table></td></tr></table></body></html>';
}
