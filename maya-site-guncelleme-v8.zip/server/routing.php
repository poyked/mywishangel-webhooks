<?php
declare(strict_types=1);
function defaultRoutePaths():array{return ['anasayfa'=>'','peynirler'=>'urunlerimiz','urun'=>'urun','paket'=>'paket','duzenli-siparis'=>'duzenli-siparis','rehber'=>'peynir-rehberi','seckiler'=>'tanisma-paketleri','hikayemiz'=>'hikayemiz','kurumsal'=>'kurumsal','iletisim'=>'iletisim','sss'=>'sik-sorulan-sorular','teslimat'=>'teslimat-ve-paketleme','politikalar'=>'gizlilik-ve-satis-bilgileri','kullanim-kosullari'=>'kullanim-kosullari','kvkk-aydinlatma'=>'kvkk-aydinlatma','mesafeli-satis'=>'mesafeli-satis','iptal-iade'=>'iptal-iade','cerez-politikasi'=>'cerez-politikasi','giris'=>'giris','kayit'=>'kayit','hesabim'=>'hesabim','sepet'=>'sepet','odeme'=>'odeme','odeme-sonuc'=>'siparis-sonucu','sifre-yenile'=>'sifre-yenile','takip'=>'siparis-takibi'];}
function editablePageRoutes():array{return ['peynirler'=>'Ürünlerimiz','seckiler'=>'Tanışma Paketleri','hikayemiz'=>'Maya’nın Hikâyesi','rehber'=>'Peynir Rehberi','kurumsal'=>'Kurumsal','iletisim'=>'İletişim','sss'=>'Sık Sorulan Sorular','teslimat'=>'Teslimat bilgileri','takip'=>'Sipariş takibi'];}
function pageRouteSettings(array $input=[],bool $strict=false):array{
 $defaults=defaultRoutePaths();$allowed=editablePageRoutes();$out=array_intersect_key($defaults,$allowed);$reserved=array_merge(['admin','api','server','storage','assets','images','videos','uploads','index','image','seo','unsubscribe','test'],array_values(array_diff_key($defaults,$allowed)));
 foreach($input as $key=>$value){if(!isset($allowed[$key])){if($strict)throw new DomainException('Bu sayfanın adresi bu alandan değiştirilemez.');continue;}if(!is_string($value)||strlen($value)>80||!preg_match('/^[a-z0-9]+(?:-[a-z0-9]+)*$/',$value)||in_array($value,$reserved,true)){if($strict)throw new DomainException('Sayfa adresi için küçük harf, rakam ve tire kullanın; sistem adresleri seçilemez.');continue;}$page=$strict?record('pages',$value):null;if($page&&($page['type']??'page')==='page'&&($page['id']??'')!==$key){if($strict)throw new DomainException('Bu adres başka bir kayıtlı sayfada kullanılıyor: '.$value);continue;}$out[$key]=$value;}
 if(count($out)!==count(array_unique($out))){if($strict)throw new DomainException('İki sayfanın adresi aynı olamaz.');return array_intersect_key($defaults,$allowed);}return $out;
}
function routePaths(?array $settings=null):array{
 if($settings===null){if(isset($GLOBALS['maya_route_paths']))return $GLOBALS['maya_route_paths'];$settings=record('settings','store')??[];return $GLOBALS['maya_route_paths']=array_replace(defaultRoutePaths(),pageRouteSettings(is_array($settings['pageRoutes']??null)?$settings['pageRoutes']:[]));}
 return array_replace(defaultRoutePaths(),pageRouteSettings(is_array($settings['pageRoutes']??null)?$settings['pageRoutes']:[]));
}

function siteBasePath():string{return rtrim((string)(parse_url(envv('APP_URL','https://mayapeynir.com'),PHP_URL_PATH)??''),'/');}
function productSlug(array $p):string{if(!empty($p['slug']))return (string)$p['slug'];$name=strtr(mb_strtolower((string)($p['name']??$p['id'])),['ı'=>'i','ş'=>'s','ğ'=>'g','ü'=>'u','ö'=>'o','ç'=>'c']);return trim(preg_replace('/[^a-z0-9]+/','-',$name),'-')?:$p['id'];}
function routeUrl(string $route='anasayfa',string $id=''):string{if($route==='urun'&&$id!==''&&findStoreBundle($id))$route='paket';if($route==='urun'&&$id!==''&&($p=record('products',$id)))$id=productSlug($p);if($route==='paket'&&$id!==''&&($bundle=findStoreBundle($id)))$id=$bundle['slug'];$path=routePaths()[$route]??$route;return rtrim(envv('APP_URL','https://mayapeynir.com'),'/').'/'.$path.($id!==''&&$id!=='all'?'/'.rawurlencode($id):'');}
function resolveStoreRoute():array{
 $path=(string)(parse_url($_SERVER['REQUEST_URI']??'/',PHP_URL_PATH)??'/');$base=siteBasePath();if($base!==''&&($path===$base||str_starts_with($path,$base.'/')))$path=substr($path,strlen($base));$path=trim(rawurldecode($path),'/');
 if(isset($_GET['p'])||isset($_GET['id'])||$path==='index.php'||$path==='index.html')return ['not-found',''];
 if($path==='')return ['anasayfa',''];$parts=explode('/',$path);if(count($parts)>2)return ['not-found',''];$route=array_search($parts[0],routePaths(),true);$id=$parts[1]??'';
 if($route===false){$page=record('pages',$parts[0]);if(count($parts)===1&&$page&&($page['active']??false)&&($page['type']??'page')==='page')return [$parts[0],''];return ['not-found',''];}
 if($id!==''&&(!in_array($route,['peynirler','urun','paket','rehber','odeme-sonuc','sifre-yenile'],true)||!preg_match('/^[a-zA-Z0-9_-]{1,100}$/',$id)))return ['not-found',''];
 if($route==='urun'&&$id!==''&&($bundle=findStoreBundle($id))){$route='paket';$id=$bundle['id'];}
 if($route==='urun'&&$id!==''){foreach(records('products') as $p)if(productSlug($p)===$id){$id=$p['id'];break;}}
 if($route==='paket'&&$id!==''){foreach((record('settings','store')['collections']['sections']??[]) as $section)if(($section['slug']??'')===$id){$id=$section['id'];break;}}
 if(in_array($route,['urun','paket','odeme-sonuc','sifre-yenile'],true)&&$id==='')return ['not-found',''];return [$route,$id];
}
