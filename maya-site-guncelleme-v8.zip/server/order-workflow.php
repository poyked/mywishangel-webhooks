<?php
declare(strict_types=1);
function orderNumber(array $order):string{$c=json_decode((string)($order['customer_json']??'{}'),true)?:[];return (string)($c['orderNumber']??$order['id']);}
function orderIsTest(array $order):bool{$c=json_decode((string)($order['customer_json']??'{}'),true)?:[];return ($c['isTest']??false)===true;}
function orderView(array $order):array{$order['number']=orderNumber($order);$order['isTest']=orderIsTest($order);return $order;}
function nextOrderNumber():string{
 if(!db()->inTransaction())throw new LogicException('Sipariş numarası işlem içinde oluşturulmalı.');
 $args=['meta','order-number',jsonval(['value'=>999]),0,date(DATE_ATOM)];
 if(envv('DB_DRIVER')==='sqlite')sql('INSERT OR IGNORE INTO records(kind,id,payload,position,updated_at) VALUES(?,?,?,?,?)',$args);
 else sql('INSERT INTO records(kind,id,payload,position,updated_at) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE id=id',$args);
 if(envv('DB_DRIVER')!=='sqlite')sql("SELECT id FROM records WHERE kind='meta' AND id='order-number' FOR UPDATE");
 $next=max(999,(int)(record('meta','order-number')['value']??999))+1;put('meta','order-number',['value'=>$next]);return (string)$next;
}
function reserveOrderItems(array $items):void{foreach($items as $item){$p=record('products',$item['id']);if(!$p)throw new DomainException('Ürün bulunamadı.');if(!empty($p['variants'])){foreach($p['variants'] as &$v)if((int)$v['weight']===(int)$item['weight']){if((int)$v['stock']<$item['qty'])throw new DomainException('Stok yetersiz.');$v['stock']-=$item['qty'];}unset($v);$p['stock']=array_sum(array_column($p['variants'],'stock'));}else{if((int)$p['stock']<$item['qty'])throw new DomainException('Stok yetersiz.');$p['stock']-=$item['qty'];}put('products',$item['id'],$p);}}
function testOrderItems():array{foreach(storeBundles() as $b)if($b['available']>0)return array_map(fn($x)=>['id'=>$x['id'],'weight'=>$x['weight'],'qty'=>$x['qty'],'packageId'=>$b['id']],$b['items']);foreach(records('products') as $p){if(!($p['active']??false))continue;foreach($p['weights']??[] as $w){$stock=(int)($p['stock']??0);foreach($p['variants']??[] as $v)if((int)$v['weight']===(int)$w)$stock=(int)$v['stock'];if($stock>0)return [['id'=>$p['id'],'weight'=>(int)$w,'qty'=>1]];}}throw new DomainException('Test siparişi için satışta ve stokta en az bir ürün olmalı.');}
function createOwnerTestOrder():array{
 require_once __DIR__.'/payments.php';
 $email='yalanimvar@gmail.com';$key='owner-test-order-20261106';$marker=record('meta',$key);if(!empty($marker['orderId']))return ['ok'=>true,'created'=>false]+$marker;
 db()->beginTransaction();try{
  $args=['meta',$key,'{}',0,date(DATE_ATOM)];
  if(envv('DB_DRIVER')==='sqlite')sql('INSERT OR IGNORE INTO records(kind,id,payload,position,updated_at) VALUES(?,?,?,?,?)',$args);else sql('INSERT INTO records(kind,id,payload,position,updated_at) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE id=id',$args);
  if(envv('DB_DRIVER')!=='sqlite'){sql("SELECT id FROM records WHERE kind='meta' AND id=? FOR UPDATE",[$key]);sql("SELECT id FROM records WHERE kind='products' ORDER BY id FOR UPDATE");}
  $marker=record('meta',$key);if(!empty($marker['orderId'])){db()->commit();return ['ok'=>true,'created'=>false]+$marker;}
  $q=quoteCart(testOrderItems());$u=sql('SELECT id,email,name,role FROM users WHERE email=?',[$email])->fetch();
  if(!$u){sql('INSERT INTO users(email,password_hash,name,role,created_at) VALUES(?,?,?,?,?)',[$email,null,'Test Müşterisi','customer',date(DATE_ATOM)]);$uid=(int)db()->lastInsertId();$u=['id'=>$uid,'email'=>$email,'name'=>'Test Müşterisi','role'=>'customer'];put('meta','owner-test-account',['userId'=>$uid,'email'=>$email]);}
  $profile=record('customer_profiles',(string)$u['id'])??[];$oid='MAYA'.date('YmdHis').bin2hex(random_bytes(8));$number=nextOrderNumber();
  $c=['name'=>$u['name'],'surname'=>'','email'=>$email,'phone'=>$profile['phone']??'Test kaydı','city'=>'İstanbul','district'=>'Test','address'=>'TEST SİPARİŞİ — Fiziksel gönderim yapılmayacak.','invoice'=>'Test kaydı; tahsilat ve fatura oluşturulmadı.','note'=>'Site sahibinin stok, kargo durumları, e-posta, yorum ve hatırlatma denemesi.','isTest'=>true,'orderNumber'=>$number,'paymentMode'=>'simulated','discount'=>$q['discount'],'coupon'=>$q['coupon'],'vat'=>$q['vat'],'regularDelivery'=>['enabled'=>true,'days'=>30]];
  reserveOrderItems($q['items']);sql('INSERT INTO orders(id,user_id,email,customer_json,items_json,subtotal,shipping,total,status,payment_status,tracking_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',[$oid,$u['id'],$email,jsonval($c),jsonval($q['items']),$q['subtotal'],$q['shipping'],$q['total'],'preparing','paid','{}',date(DATE_ATOM),date(DATE_ATOM)]);
  $order=['id'=>$oid,'user_id'=>$u['id'],'email'=>$email,'customer_json'=>jsonval($c),'items_json'=>jsonval($q['items']),'payment_status'=>'paid'];regularDeliveryOnPaidOrder($order);
  $plan=record('regular_requests','rec-'.$oid);if($plan){$plan['status']='active';$plan['isTest']=true;$plan['nextDate']=(new DateTimeImmutable())->modify('+2 days')->format('Y-m-d');$plan['leadDays']=2;$plan['discountPercent']=10;put('regular_requests',$plan['id'],$plan);}
  $contactKey=hash('sha256',$email);$contact=record('contacts',$contactKey)??['id'=>$contactKey,'email'=>$email,'name'=>$u['name'],'source'=>'Site sahibinin test siparişi','created_at'=>date(DATE_ATOM)];if(($contact['marketing']??'')!=='unsubscribed'&&!record('mail_suppressions',$contactKey)){$contact['marketing']='subscribed';$contact['consentProof']='Site sahibi kendi e-postasıyla pazarlama testi istedi · '.date(DATE_ATOM);}put('contacts',$contactKey,$contact);
  enqueue('order-paid-customer-'.$oid,'customer',$email,'[TEST] '.$number.' numaralı siparişiniz hazır','Bu bir test siparişidir; kartınızdan ödeme alınmadı. '.$number.' numaralı siparişiniz hazırlanıyor. Durum ve stok denemelerini yönetim panelinden yapabilirsiniz.');
  $marker=['orderId'=>$oid,'number'=>$number,'email'=>$email,'created_at'=>date(DATE_ATOM)];put('meta',$key,$marker);bump();audit('order.test-created',$marker);db()->commit();return ['ok'=>true,'created'=>true]+$marker;
 }catch(Throwable $e){if(db()->inTransaction())db()->rollBack();throw $e;}
}
function orderWorkflowRoutes(string $route,string $method):void{
 if($route==='owner-test-order'&&$method==='POST'){owner();respond(createOwnerTestOrder());}
 if($route!=='track-order'||$method!=='POST')return;
 limit('track-order',10,900);$d=input();$number=trim((string)($d['number']??''));$email=mb_strtolower(trim((string)($d['email']??'')));if(!$number||strlen($number)>80||!filter_var($email,FILTER_VALIDATE_EMAIL))respond(['error'=>'Sipariş numarası ve siparişte kullandığınız e-posta gerekli.'],422);
 foreach(sql('SELECT id,status,payment_status,total,customer_json,tracking_json,created_at FROM orders WHERE LOWER(email)=? ORDER BY created_at DESC LIMIT 200',[$email])->fetchAll() as $o)if($number===$o['id']||$number===orderNumber($o)){$view=orderView($o);unset($view['customer_json']);respond(['order'=>$view]);}
 respond(['error'=>'Bu numara ve e-posta ile eşleşen sipariş bulunamadı.'],404);
}
