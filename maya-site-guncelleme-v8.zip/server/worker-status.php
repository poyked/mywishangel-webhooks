<?php
declare(strict_types=1);
function runWorkerTasks(array $tasks):array{
 $start=microtime(true);$run=['startedAt'=>date(DATE_ATOM),'finishedAt'=>null,'status'=>'running','tasks'=>[]];put('worker_status','last',$run);$failed=false;
 foreach($tasks as $name=>$fn){try{$result=$fn();$taskFailed=is_array($result)&&(int)($result['failed']??0)>0;if($taskFailed)$failed=true;$skipped=is_array($result)&&(($result['enabled']??null)===false||isset($result['skipped']));$run['tasks'][$name]=['status'=>$taskFailed?'partial_failure':($skipped?'skipped':'complete'),'result'=>$result];}catch(Throwable $e){$failed=true;logError($e);$run['tasks'][$name]=['status'=>'failed','message'=>'Görev tamamlanamadı. Sunucu kayıtlarını kontrol edin.'];}put('worker_status','last',$run);}
 $run['status']=$failed?'partial_failure':'complete';$run['finishedAt']=date(DATE_ATOM);$run['durationSeconds']=round(microtime(true)-$start,2);put('worker_status','last',$run);return $run;
}
function workerPublicStatus():array{$row=record('worker_status','last');if(!$row)return ['seen'=>false,'message'=>'Bu sürümün worker çalışması henüz görülmedi. Mevcut cron yolu server/worker.php olmalı.'];return ['seen'=>true,'startedAt'=>$row['startedAt'],'finishedAt'=>$row['finishedAt']??null,'status'=>$row['status'],'durationSeconds'=>$row['durationSeconds']??null,'stale'=>(time()-(strtotime($row['startedAt'])?:0))>900,'tasks'=>array_map(fn($t)=>['status'=>$t['status']],$row['tasks'])];}
