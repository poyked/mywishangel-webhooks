<?php
declare(strict_types=1);
function aiPackageImageContext(string $json):?array{
 $editing=json_decode($json,true);if(!is_array($editing)||($editing['section']??'')!=='collection-section')return null;
 $items=$editing['fields']['packageItems']??[];if(!is_array($items)||!$items||count($items)>12)throw new DomainException('Paket görseli için önce paketteki ürünleri seçin.');
 $products=[];$references=[];$positions=[];
 foreach($items as $item){$id=(string)($item['id']??'');$p=record('products',$id);$weight=(int)($item['weight']??0);$qty=(int)($item['qty']??0);if(!$p||!($p['active']??false)||!in_array($weight,array_map('intval',$p['weights']??[]),true)||$qty<1||$qty>20)throw new DomainException('Paketin ürün, gramaj ve adet seçimini kontrol edin.');if(empty($p['image']))throw new DomainException($p['name'].' için önce ana ürün görseli ekleyin.');
  if(!isset($positions[$id])){$references[]=['id'=>$id,'name'=>$p['name'],'image'=>$p['image']];$positions[$id]=count($references);}
  $products[]=['id'=>$id,'name'=>$p['name'],'weight'=>$weight,'qty'=>$qty,'referenceImage'=>$positions[$id]];
 }
 return ['packageProducts'=>$products,'imageReferences'=>$references];
}
function aiImageReferenceData(array $references):array{
 $result=[];$total=0;foreach($references as $reference){$data=aiReferenceImage((string)($reference['image']??''));if(!$data)throw new DomainException(($reference['name']??'Ürün').' ana görseli okunamadı. Lütfen ürün görselini kontrol edin.');$total+=strlen($data);if($total>32*1024*1024)throw new DomainException('Referans görselleri çok büyük. Sunucuda GD görsel desteğini etkinleştirin veya daha küçük ana görseller seçin.');$result[]=$data;}return $result;
}
function aiImageTransport(array $body,array $references):array{
 if(!$references)return ['path'=>'images/generations','contentType'=>'application/json','payload'=>jsonval($body)];
 $boundary='maya-'.bin2hex(random_bytes(16));$payload='';foreach($body as $key=>$value)$payload.='--'.$boundary."\r\nContent-Disposition: form-data; name=\"".$key."\"\r\n\r\n".(string)$value."\r\n";
 foreach($references as $i=>$data){if(!preg_match('~^data:(image/(?:jpeg|png|webp));base64,(.+)$~s',$data,$match))throw new DomainException('Referans görseli geçersiz.');$raw=base64_decode($match[2],true);if(!$raw||!getimagesizefromstring($raw))throw new DomainException('Referans görseli okunamadı.');$ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$match[1]];$payload.='--'.$boundary."\r\nContent-Disposition: form-data; name=\"image[]\"; filename=\"product-".($i+1).'.'.$ext."\"\r\nContent-Type: ".$match[1]."\r\n\r\n".$raw."\r\n";}
 $payload.='--'.$boundary."--\r\n";return ['path'=>'images/edits','contentType'=>'multipart/form-data; boundary='.$boundary,'payload'=>$payload];
}
