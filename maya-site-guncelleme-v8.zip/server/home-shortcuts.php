<?php
declare(strict_types=1);
function homeShortcutDefaults(array $settings=[]):array{return [['id'=>'shortcut-white','label'=>'Beyaz Peynirler','target'=>'peynirler/beyaz','enabled'=>true],['id'=>'shortcut-kasar','label'=>'Kaşar Peynirleri','target'=>'peynirler/kasar','enabled'=>true],['id'=>'shortcut-packages','label'=>$settings['navigationLabels']['seckiler']??$settings['collections']['title']??'Kahvaltı Seçkileri','target'=>'seckiler','enabled'=>true],['id'=>'shortcut-all','label'=>'Tüm Ürünler →','target'=>'peynirler','enabled'=>true]];}
function homeShortcutTarget(string $target):bool{
 $parts=explode('/',$target);if(count($parts)>2||!preg_match('~^[a-zA-Z0-9_-]+(?:/[a-zA-Z0-9_-]+)?$~',$target))return false;[$route,$id]=array_pad($parts,2,'');
 if($id===''){if(in_array($route,['anasayfa','peynirler','seckiler','hikayemiz','rehber','kurumsal','iletisim','sss','teslimat','politikalar','takip'],true))return true;$page=record('pages',$route);return $page&&($page['active']??false)&&($page['type']??'page')==='page'&&!in_array($route,['giris','hesabim','odeme','sepet','api','admin','server','storage','assets','sifre-yenile','duzenli-siparis'],true);}
 return match($route){'peynirler'=>$id==='all'||(bool)(record('categories',$id)['active']??false),'urun'=>(bool)(record('products',$id)['active']??false),'paket'=>findStoreBundle($id)!==null,'rehber'=>($page=record('pages',$id))&&($page['active']??false)&&($page['type']??'')==='blog',default=>false};
}
function homeShortcutSettings(?array $items,array $settings=[],bool $strict=false):array{
 if($items===null)return homeShortcutDefaults($settings);if(count($items)>12){if($strict)throw new DomainException('En fazla 12 ana sayfa kısayolu ekleyin.');$items=array_slice($items,0,12);}$result=[];$ids=[];
 foreach($items as $item){if(!is_array($item)){if($strict)throw new DomainException('Kısayol satırını kontrol edin.');continue;}$id=(string)($item['id']??'');if(!$id)$id='shortcut-'.bin2hex(random_bytes(8));if(!preg_match('/^[a-zA-Z0-9_-]{1,70}$/',$id)||isset($ids[$id])){if($strict)throw new DomainException('Kısayol kimlikleri farklı olmalı.');continue;}$ids[$id]=true;$label=mb_substr(trim((string)($item['label']??'')),0,80);$target=trim((string)($item['target']??''));$enabled=($item['enabled']??true)===true;
  if(!$label||!homeShortcutTarget($target)&&($enabled||!preg_match('~^[a-zA-Z0-9_-]+(?:/[a-zA-Z0-9_-]+)?$~',$target))){if($strict)throw new DomainException('Kısayolun adını yazın ve listeden yayındaki bir hedef seçin.');continue;}$result[]=['id'=>$id,'label'=>$label,'target'=>$target,'enabled'=>$enabled];
 }return $result;
}
