<?php
declare(strict_types=1);
// Public identifiers are separate from credentials; secrets never enter bootstrap HTML.
function trackingPublicConfig():array{
 $base=parse_url(envv('APP_URL'),PHP_URL_PATH)?:'';$staging=trim($base,'/')!==''||envv('APP_ENV')!=='production';$test=envv('TRACKING_TEST_MODE')==='true';$allowed=!$staging||$test;
 $ga=strtoupper(envv('GA4_MEASUREMENT_ID'));$meta=envv('META_PIXEL_ID');
 return ['ga4'=>['enabled'=>$allowed&&envv('GA4_ENABLED')==='true'&&(bool)preg_match('/^G-[A-Z0-9]{4,20}$/',$ga),'id'=>$ga], 'meta'=>['enabled'=>$allowed&&envv('META_ENABLED')==='true'&&(bool)preg_match('/^[0-9]{5,25}$/',$meta)&&(!$test||envv('META_TEST_EVENT_CODE')!==''),'id'=>$meta], 'testMode'=>$test,'staging'=>$staging];
}
function trackingConsent(array $input):array{
 $value=['analytics'=>($input['analytics']??false)===true,'marketing'=>($input['marketing']??false)===true];
 if(empty($_SESSION['tracking_key']))$_SESSION['tracking_key']=bin2hex(random_bytes(20));$value['key']=hash('sha256',$_SESSION['tracking_key']);$value['time']=time();
 put('tracking_consents',$value['key'],$value);return $value;
}
function metaPhoneNumber(string $raw):string{$digits=preg_replace('/\D/','',$raw);if(str_starts_with($digits,'00'))$digits=substr($digits,2);if(strlen($digits)===11&&$digits[0]==='0')$digits=substr($digits,1);if(strlen($digits)===10)$digits='90'.$digits;return preg_match('/^[1-9][0-9]{7,14}$/',$digits)?$digits:'';}
function trackingCheckoutContext(array $input):array{
 $consent=trackingConsent($input);$t=$consent;
 if($consent['analytics']){foreach(['clientId'=>'/^[0-9]{1,20}\.[0-9]{1,20}$/','sessionId'=>'/^[0-9]{1,20}$/'] as $key=>$pattern){$v=(string)($input[$key]??'');if(preg_match($pattern,$v))$t[$key]=$v;}$t['clientId']=$t['clientId']??random_int(100000000,999999999).'.'.time();}
 if($consent['marketing']){foreach(['fbp','fbc'] as $key){$v=(string)($input[$key]??'');if(preg_match('/^fb\.[0-9]+\.[0-9]{10,16}\.[a-zA-Z0-9_-]{1,200}$/',$v))$t[$key]=$v;}$ip=(string)($_SERVER['REMOTE_ADDR']??'');if(filter_var($ip,FILTER_VALIDATE_IP))$t['ip']=$ip;$t['agent']=substr((string)($_SERVER['HTTP_USER_AGENT']??''),0,500);}
 return $t;
}
function trackingPurchaseData(array $o):array{
 $c=json_decode($o['customer_json']??'{}',true)?:[];$items=json_decode($o['items_json']??'[]',true)?:[];$discount=max(0,(int)($c['discount']??0));$subtotal=max(0,(int)$o['subtotal']);$allocated=0;$list=[];
 foreach($items as $i=>$x){$gross=(int)$x['unit']*(int)$x['qty'];$part=$i===array_key_last($items)?max(0,$discount-$allocated):($subtotal?(int)round($discount*$gross/$subtotal):0);$part=min($gross,$part);$allocated+=$part;$list[]=['item_id'=>(string)$x['id'],'item_name'=>(string)$x['name'],'item_variant'=>(string)$x['weight'].' g','price'=>round(($gross-$part)/max(1,(int)$x['qty'])/100,4),'quantity'=>(int)$x['qty']];}
 return ['transaction_id'=>(string)$o['id'],'currency'=>'TRY','value'=>max(0,((int)$o['total']-(int)$o['shipping'])/100),'shipping'=>(int)$o['shipping']/100,'items'=>$list];
}
function queueTrackingPurchase(array $o):void{
 if(($o['payment_status']??'')!=='paid'||orderIsTest($o))return;$c=json_decode($o['customer_json']??'{}',true)?:[];$t=$c['tracking']??[];$config=trackingPublicConfig();if(envv('PAYTR_TEST_MODE','1')!=='0'&&!$config['testMode'])return;
 $purchase=trackingPurchaseData($o);$eventTime=time();foreach(['ga4'=>'analytics','meta'=>'marketing'] as $provider=>$purpose){if(!($t[$purpose]??false)||!$config[$provider]['enabled']||envv($provider==='ga4'?'GA4_API_SECRET':'META_ACCESS_TOKEN')==='')continue;
  $id=hash('sha256',$provider.'|purchase|'.$o['id']);if(record('conversion_queue',$id))continue;
  $event=['id'=>$id,'provider'=>$provider,'destination'=>$config[$provider]['id'],'orderId'=>$o['id'],'consentKey'=>$t['key']??'','eventId'=>'purchase_'.$o['id'],'eventTime'=>$eventTime,'testMode'=>$config['testMode'],'purchase'=>$purchase,'status'=>'pending','attempts'=>0,'nextAttempt'=>0,'created'=>date(DATE_ATOM)];
  if($provider==='ga4'){$event['clientId']=$t['clientId']??'';$event['sessionId']=$t['sessionId']??'';}
  else{$event['userData']=[];$email=strtolower(trim((string)($o['email']??'')));if(filter_var($email,FILTER_VALIDATE_EMAIL))$event['userData']['em']=[hash('sha256',$email)];$phone=metaPhoneNumber((string)($c['phone']??''));if($phone!=='')$event['userData']['ph']=[hash('sha256',$phone)];if(filter_var($t['ip']??'',FILTER_VALIDATE_IP))$event['userData']['client_ip_address']=$t['ip'];foreach(['fbp','fbc'] as $key)if(!empty($t[$key]))$event['userData'][$key]=$t[$key];if(!empty($t['agent']))$event['userData']['client_user_agent']=$t['agent'];}
  put('conversion_queue',$id,$event);
 }
}
function trackingPurchaseForBrowser(array $o):?array{
 if(($o['payment_status']??'')!=='paid'||orderIsTest($o))return null;$config=trackingPublicConfig();if(envv('PAYTR_TEST_MODE','1')!=='0'&&!$config['testMode'])return null;$p=trackingPurchaseData($o);$p['eventId']='purchase_'.$o['id'];
 $p['serverGa4']=(bool)record('conversion_queue',hash('sha256','ga4|purchase|'.$o['id']));$p['serverMeta']=(bool)record('conversion_queue',hash('sha256','meta|purchase|'.$o['id']));return $p;
}
function trackingProviderRequest(array $e):array{
 $p=$e['purchase'];if($e['provider']==='ga4'){$params=$p+['engagement_time_msec'=>1];if($e['sessionId'])$params['session_id']=(int)$e['sessionId'];if($e['testMode'])$params['debug_mode']=true;
  return ['url'=>'https://www.google-analytics.com/mp/collect?'.http_build_query(['measurement_id'=>$e['destination'],'api_secret'=>envv('GA4_API_SECRET')]),'headers'=>['Content-Type: application/json'],'body'=>['client_id'=>$e['clientId'],'timestamp_micros'=>$e['eventTime']*1000000,'events'=>[['name'=>'purchase','params'=>$params]]]];
 }
 $contents=array_map(fn($x)=>['id'=>$x['item_id'],'quantity'=>$x['quantity'],'item_price'=>$x['price']],$p['items']);$body=['data'=>[['event_name'=>'Purchase','event_time'=>$e['eventTime'],'event_id'=>$e['eventId'],'action_source'=>'website','event_source_url'=>routeUrl('anasayfa'),'user_data'=>$e['userData'],'custom_data'=>['currency'=>'TRY','value'=>$p['value']+$p['shipping'],'order_id'=>$p['transaction_id'],'content_type'=>'product','content_ids'=>array_column($p['items'],'item_id'),'contents'=>$contents,'num_items'=>array_sum(array_column($p['items'],'quantity'))]]]];if($e['testMode'])$body['test_event_code']=envv('META_TEST_EVENT_CODE');
 return ['url'=>'https://graph.facebook.com/v23.0/'.$e['destination'].'/events','headers'=>['Content-Type: application/json','Authorization: Bearer '.envv('META_ACCESS_TOKEN')],'body'=>$body];
}
function processTrackingQueue(int $maximum=20):array{
 $stats=['sent'=>0,'retry'=>0,'cancelled'=>0,'failed'=>0];$config=trackingPublicConfig();$count=0;
 foreach(records('conversion_queue') as $e){if(!in_array($e['status'],['pending','retry'],true)||($e['nextAttempt']??0)>time())continue;if(++$count>$maximum)break;$purpose=$e['provider']==='ga4'?'analytics':'marketing';$consent=record('tracking_consents',$e['consentKey'])??[];
  if(!($consent[$purpose]??false)||!$config[$e['provider']]['enabled']||$config[$e['provider']]['id']!==$e['destination']||$config['testMode']!==$e['testMode']){$e['status']='cancelled';$stats['cancelled']++;}
  elseif(time()-$e['eventTime']>2*86400){$e['status']='failed';$e['error']='Gönderim süresi doldu.';$stats['failed']++;}
  else{try{if(envv($e['provider']==='ga4'?'GA4_API_SECRET':'META_ACCESS_TOKEN')==='')throw new RuntimeException('Sunucu anahtarı eksik.');$request=trackingProviderRequest($e);$ch=curl_init($request['url']);curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_HTTPHEADER=>$request['headers'],CURLOPT_POSTFIELDS=>jsonval($request['body']),CURLOPT_RETURNTRANSFER=>true,CURLOPT_TIMEOUT=>15,CURLOPT_CONNECTTIMEOUT=>5]);$raw=curl_exec($ch);$code=curl_getinfo($ch,CURLINFO_RESPONSE_CODE);curl_close($ch);$r=json_decode((string)$raw,true);if($code<200||$code>=300||($e['provider']==='meta'&&($r['events_received']??0)<1))throw new RuntimeException('Sağlayıcı gönderimi kabul etmedi (HTTP '.(int)$code.').');$e['status']='sent';$e['sentAt']=date(DATE_ATOM);$stats['sent']++;unset($e['error']);}
   catch(Throwable $error){$e['attempts']++;$e['status']=$e['attempts']>=6?'failed':'retry';$e['nextAttempt']=time()+min(21600,60*(2**$e['attempts']));$e['error']=$error instanceof RuntimeException?$error->getMessage():'Ölçüm sağlayıcısına bağlanılamadı.';$stats[$e['status']==='retry'?'retry':'failed']++;}
  }
  // Personal matching data is only needed while delivery is pending.
  if(in_array($e['status'],['sent','cancelled','failed'],true))unset($e['userData'],$e['clientId'],$e['sessionId']);put('conversion_queue',$e['id'],$e);
 }
 // Bound retention of tracking-only records. Orders retain their normal business history.
 foreach(['conversion_queue'=>'eventTime','tracking_consents'=>'time'] as $kind=>$key)foreach(records($kind) as $row)if(($row[$key]??time())<time()-30*86400)sql('DELETE FROM records WHERE kind=? AND id=?',[$kind,$row['id']??$row['key']]);
 return $stats;
}
function trackingRoutes(string $route,string $method):void{
 if($route==='tracking-consent'&&$method==='POST'){limit('tracking-consent',120,300);$d=input();trackingConsent($d);respond(['ok'=>true]);}
}
