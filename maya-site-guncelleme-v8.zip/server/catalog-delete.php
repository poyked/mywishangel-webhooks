<?php
declare(strict_types=1);
function deleteCatalogProduct(string $id):array{
 if($bundle=record('bundles',$id)){closeTrendyolProductListings($id);deleteBundleProduct($id);return [];}
 $product=record('products',$id);if(!$product)return [];
 $inventory=inventorySnapshot();if(($inventory[$id]['reserved']??0)>0)throw new DomainException('Bu ürünün hazırlanmakta olan siparişi var. Sipariş tamamlandıktan sonra silin.');
 $affected=[];foreach(records('bundles') as $b)if(empty($b['deleted'])&&in_array($id,array_column($b['items']??[],'id'),true))$affected[]=$b;
 closeTrendyolProductListings($id);foreach($affected as $b)closeTrendyolProductListings($b['id']);
 $own=!db()->inTransaction();if($own)db()->beginTransaction();try{if(envv('DB_DRIVER')!=='sqlite')sql("SELECT id FROM records WHERE kind='products' AND id=? FOR UPDATE",[$id]);$lockedInventory=inventorySnapshot();if(($lockedInventory[$id]['reserved']??0)>0)throw new DomainException('Bu ürünün hazırlanmakta olan siparişi var. Sipariş tamamlandıktan sonra silin.');
  put('deleted_products',$id,['id'=>$id,'value'=>$product,'deleted_at'=>date(DATE_ATOM)]);
  $settings=record('settings','store')??[];
  foreach($affected as $b){$b['items']=array_values(array_filter($b['items'],fn($x)=>$x['id']!==$id));$b['active']=false;$b['showOnCollections']=false;$b['revision']=($b['revision']??0)+1;put('bundles',$b['id'],$b);}
  foreach($settings['homeGroups']??[] as $i=>$g){$ids=$g['products']??[];$settings['homeGroups'][$i]['products']=array_values(array_filter($ids,fn($pid)=>$pid!==$id));if($ids&&!$settings['homeGroups'][$i]['products'])$settings['homeGroups'][$i]['enabled']=false;}
  foreach($settings['collections']['sections']??[] as $i=>$section){if(in_array($section['bundleId']??'',array_column($affected,'id'),true))$settings['collections']['sections'][$i]['enabled']=false;foreach(['products','items'] as $key)if(isset($section[$key]))$settings['collections']['sections'][$i][$key]=array_values(array_filter($section[$key],fn($x)=>(is_array($x)?($x['id']??''):$x)!==$id));}
  foreach($settings['homeShortcuts']??[] as $i=>$shortcut)if(in_array($shortcut['target']??'',['urun/'.$id,'urun/'.productSlug($product)],true))unset($settings['homeShortcuts'][$i]);if(isset($settings['homeShortcuts']))$settings['homeShortcuts']=array_values($settings['homeShortcuts']);
  foreach(records('cross_sell') as $rule)if(in_array($id,[$rule['product']??'',$rule['related']??''],true))sql('DELETE FROM records WHERE kind=? AND id=?',['cross_sell',$rule['id']]);
  put('settings','store',$settings);sql('DELETE FROM records WHERE kind=? AND id=?',['products',$id]);bump();audit('products.delete',['id'=>$id,'affectedPackages'=>array_column($affected,'id')]);if($own)db()->commit();return array_column($affected,'id');
 }catch(Throwable $e){if($own&&db()->inTransaction())db()->rollBack();throw $e;}
}
