<?php
declare(strict_types=1);
function ensurePageCatalog():void{
 if(record('meta','page-catalog-v1'))return;
 $pages=[
 ['hikayemiz','Maya’nın Hikâyesi','page','Maya’nın hikâyesi, 1970’lerin başında İstanbul Üsküdar’da üç tekerlekli bir peynir arabasıyla başlıyor. Zamanla büyüyen bu yolculuğun merkezinde peynir ve sofralarla kurulan bağ var.'."\n\n".'## Üsküdar’dan sofranıza'."\n\n".'Küçük bir işletmeden gelişen tedarik tecrübesine uzanan Maya, geçmişten gelen peynir bilgisini bugün ev sofralarıyla buluşturuyor. Beyaz peynirden kaşara uzanan seçkimizde, kahvaltınıza ve mutfağınıza eşlik edecek lezzetleri keşfedebilirsiniz.','images/sofra.webp',true],
 ['kurumsal','Kurumsal Maya','page','Otel, restoran ve profesyonel mutfaklar için ürün ve tedarik taleplerinizi birlikte değerlendirelim.'."\n\n".'## İşletmenize uygun ürün seçimi'."\n\n".'Kahvaltı servisi ve sıcak mutfak kullanımı için peynir çeşitlerimizi inceleyin. Gramaj, miktar ve teslimat beklentinizi paylaşın; kurumsal görüşmeyi ihtiyaçlarınıza göre hazırlayalım.','images/sofra.webp',true],
 ['teslimat','Teslimat ve paketleme','page','Kargoya veriliş ve teslimat farklı adımlardır. Tahmini tarihler ürün sayfasındaki güncel gönderim planında gösterilir.'."\n\n".'## Paketleme ve saklama'."\n\n".'Teslim aldığınız ürünün ambalajını ve etiket üzerindeki saklama koşullarını kontrol edin. Teslimat veya ambalajla ilgili bir sorunuz olduğunda sipariş bilgilerinizle bizimle iletişime geçin.','',true],
 ['politikalar','Gizlilik ve satış bilgileri','page','Hesap, sipariş ve iletişim işlemlerinizde verdiğiniz bilgiler ilgili hizmetin yürütülmesi için kullanılır. İsteğe bağlı ölçüm ve pazarlama tercihleri çerez panelinden yönetilir.'."\n\n".'Üyelik koşulları, KVKK aydınlatması, satış ve iade metinleri aşağıdaki ayrı sayfalarda yer alır.','',true],
 ['kullanim-kosullari','Kullanım Koşulları','page','','',false],
 ['kvkk-aydinlatma','KVKK Aydınlatma Metni','page','','',false],
 ['mesafeli-satis','Mesafeli Satış Sözleşmesi','page','','',false],
 ['iptal-iade','İptal ve İade Koşulları','page','','',false],
 ['cerez-politikasi','Çerez Politikası','page','','',false],
 ['otel-kahvaltisi','Evde güzel bir kahvaltı sofrası.','blog','Güzel bir kahvaltı için çok sayıda üründen önce dengeli bir seçim yapın. Sofraya kaç kişinin oturacağını ve hangi peynirleri sevdiğinizi düşünerek başlayın.'."\n\n".'## Birbirini tamamlayan lezzetler'."\n\n".'Beyaz peynir ve kaşar gibi farklı dokuları bir araya getirebilir, yanında ekmek ve sevdiğiniz kahvaltılıklarla sade bir sunum hazırlayabilirsiniz.'."\n\n".'## Servis ve saklama'."\n\n".'Tüketeceğiniz miktarı servis edin; kalan ürünün saklama koşulları için kendi etiketini esas alın.','images/sofra.webp',true],
 ['peynir-secimi','Sofranıza hangi peynir yakışır?','blog','Peynir seçerken kullanımınızı düşünün: kahvaltıda dilimlemek, sıcak bir tarifte kullanmak veya bir peynir tabağı hazırlamak farklı beklentiler yaratabilir.'."\n\n".'## Ürünü tanıyarak seçin'."\n\n".'Gramajı, içeriği, alerjen bilgisini ve saklama koşullarını ürün açıklaması ve etiketi üzerinden inceleyin. Yalnız ürün adı bütün özelliklerini anlatmaz.'."\n\n".'## Kendi sofranız için'."\n\n".'Yeni bir çeşidi ilk kez deniyorsanız tüketiminize uygun miktar seçin. Merak ettiğiniz ürün ayrıntılarını satın almadan önce bize sorabilirsiniz.','images/eski-kasar.webp',true],
 ['saklama','Paket açıldıktan sonra.','blog','Peynirin saklama koşulları ürüne ve ambalajına göre değişebilir. Öncelikle ürün etiketindeki sıcaklık, son tüketim tarihi ve açıldıktan sonraki kullanım talimatlarını inceleyin.'."\n\n".'## Etiketi esas alın'."\n\n".'Tüm peynirler için tek bir saklama süresi varsaymayın. Orijinal ambalaj ve üretici talimatları ürününüze ilişkin en doğru başlangıç bilgisidir.'."\n\n".'## Bir sorunuz varsa'."\n\n".'Ambalaj veya ürünle ilgili şüpheniz varsa tüketmeden önce mağazamızla iletişime geçin.','images/beyaz.webp',true]
 ];
 db()->beginTransaction();try{foreach($pages as [$id,$title,$type,$body,$image,$active]){if(record('pages',$id))continue;put('pages',$id,['id'=>$id,'title'=>$title,'type'=>$type,'body'=>$body,'excerpt'=>mb_substr(str_replace('## ','',$body),0,160),'image'=>$image,'active'=>$active]);}put('meta','page-catalog-v1',['completed'=>date(DATE_ATOM)]);bump();db()->commit();}catch(Throwable $e){db()->rollBack();throw $e;}
}
ensurePageCatalog();

function ensureTestLegalPages():void{
 $path=__DIR__.'/test-legal-pages.json';
 if(!file_exists($path))return;
 $pages=json_decode(file_get_contents($path),true,512,JSON_THROW_ON_ERROR);
 foreach($pages as $id=>$page){
  $existing=record('pages',$id);
  if(!$existing||trim((string)($existing['body']??''))===''||empty($existing['active'])){
   put('pages',$id,$page);
  }
 }
}
ensureTestLegalPages();
