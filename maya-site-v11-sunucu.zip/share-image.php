<?php
declare(strict_types=1);
ini_set('display_errors','0');require __DIR__.'/server/share-preview.php';
$path=$_GET['src']??'images/maya-logo.png';$source=is_string($path)?sharePreviewSource($path):null;
if(!$source){http_response_code(404);exit;}
$folder=__DIR__.'/storage/image-cache';$key=hash('sha256','share-v1|'.hash_file('sha256',$source['file']));$cache=$folder.'/share-'.$key.'.jpg';
if(!function_exists('imagejpeg'))$cache=__DIR__.'/assets/images/share-preview.jpg';
elseif(!is_file($cache)){
 if(!is_dir($folder)&&!@mkdir($folder,0755,true)){http_response_code(503);exit;}
 $temp=$cache.'.'.bin2hex(random_bytes(6));if(!sharePreviewJpeg($source,$temp)||!rename($temp,$cache)){@unlink($temp);http_response_code(503);exit;}
}
if(!is_file($cache)){http_response_code(503);exit;}
header('Content-Type: image/jpeg');header('Cache-Control: public, max-age=604800');header('X-Content-Type-Options: nosniff');header('ETag: "'.$key.'"');
if(($_SERVER['HTTP_IF_NONE_MATCH']??'')==='"'.$key.'"'){http_response_code(304);exit;}
header('Content-Length: '.filesize($cache));readfile($cache);
