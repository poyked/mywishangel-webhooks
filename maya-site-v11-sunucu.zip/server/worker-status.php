<?php
declare(strict_types=1);
function runWorkerTasks(array $tasks):array{
 $start=microtime(true);$run=['startedAt'=>date(DATE_ATOM),'finishedAt'=>null,'status'=>'running','tasks'=>[]];put('worker_status','last',$run);$failed=false;
 foreach($tasks as $name=>$fn){try{$result=$fn();$taskFailed=is_array($result)&&(int)($result['failed']??0)>0;if($taskFailed)$failed=true;$skipped=is_array($result)&&(($result['enabled']??null)===false||isset($result['skipped']));$run['tasks'][$name]=['status'=>$taskFailed?'partial_failure':($skipped?'skipped':'complete'),'result'=>$result];}catch(Throwable $e){$failed=true;logError($e);$run['tasks'][$name]=['status'=>'failed','message'=>'Görev tamamlanamadı. Sunucu kayıtlarını kontrol edin.'];}put('worker_status','last',$run);}
 $run['status']=$failed?'partial_failure':'complete';$run['finishedAt']=date(DATE_ATOM);$run['durationSeconds']=round(microtime(true)-$start,2);put('worker_status','last',$run);return $run;
}
function workerPublicStatus():array{$row=record('worker_status','last');if(!$row)return ['seen'=>false,'message'=>'Bu sürümün worker çalışması henüz görülmedi. Mevcut cron yolu server/worker.php olmalı.'];return ['seen'=>true,'startedAt'=>$row['startedAt'],'finishedAt'=>$row['finishedAt']??null,'status'=>$row['status'],'durationSeconds'=>$row['durationSeconds']??null,'stale'=>(time()-(strtotime($row['startedAt'])?:0))>900,'tasks'=>array_map('workerTaskPublic',$row['tasks'])];}

function workerTaskPublic(array $task):array{
 $out=['status'=>$task['status']];$r=$task['result']??[];if(!is_array($r))return $out;
 if(($r['reason']??'')==='credentials')$out['message']='Bağlantı kapalı: mağaza ID veya API bilgileri eksik.';
 elseif(($r['reason']??'')==='order-sync-disabled')$out['message']='Trendyol sipariş aktarımı ayarlardan kapalı.';
 elseif(($r['skipped']??'')==='interval')$out['message']='Kontrol aralığı bekleniyor.';
 elseif(isset($r['checked']))$out['message']=(int)$r['checked'].' ürün aktarım sonucu kontrol edildi; '.(int)($r['failed']??0).' hata.';
 elseif(isset($r['processed']))$out['message']=(int)$r['processed'].' görev işlendi; '.(int)($r['failed']??0).' hata.';
 return $out;
}
