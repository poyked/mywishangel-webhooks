<?php
declare(strict_types=1);
function sharePreviewSource(string $path):?array{
 if(!preg_match('~^images/[\pL\pM\pN_./-]+\.(?:png|webp|jpe?g)$~u',$path)||str_contains($path,'..'))return null;
 $root=dirname(__DIR__);$base=realpath($root.'/assets/images');$file=realpath($root.'/assets/'.$path);
 if(!$base||!$file||!str_starts_with($file,$base.DIRECTORY_SEPARATOR)||!is_file($file)||filesize($file)>12*1024*1024)return null;
 $size=@getimagesize($file);if(!$size||$size[0]*$size[1]>30000000)return null;
 return ['file'=>$file,'width'=>$size[0],'height'=>$size[1],'mime'=>$size['mime']??'image/jpeg'];
}
function sharePreviewInfo(string $path):array{
 if(!sharePreviewSource($path))$path='images/maya-logo.png';$source=sharePreviewSource($path);$base=rtrim(envv('APP_URL'),'/');
 if(!$source||!function_exists('imagejpeg'))return ['url'=>$base.'/assets/images/share-preview.jpg','width'=>1200,'height'=>630,'type'=>'image/jpeg'];
 return ['url'=>$base.'/share-image.php?src='.rawurlencode($path).'&v='.substr(hash_file('sha256',$source['file']),0,16),'width'=>1200,'height'=>630,'type'=>'image/jpeg'];
}
function sharePreviewJpeg(array $source,string $target):bool{
 if(!function_exists('imagejpeg'))return false;$input=@imagecreatefromstring(file_get_contents($source['file']));if(!$input)return false;
 $out=imagecreatetruecolor(1200,630);imagefill($out,0,0,imagecolorallocate($out,247,244,235));
 $ratio=min(1080/$source['width'],510/$source['height']);$w=(int)round($source['width']*$ratio);$h=(int)round($source['height']*$ratio);
 imagecopyresampled($out,$input,(int)((1200-$w)/2),(int)((630-$h)/2),0,0,$w,$h,$source['width'],$source['height']);
 return imagejpeg($out,$target,88);
}
