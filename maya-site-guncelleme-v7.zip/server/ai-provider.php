<?php
declare(strict_types=1);

final class AiProviderException extends DomainException{
 public function __construct(public array $diagnostic){parent::__construct($diagnostic['message']);}
}
function aiModelIdValid(mixed $id):bool{return is_string($id)&&preg_match('/^[a-zA-Z0-9][a-zA-Z0-9_.:\/-]{0,199}$/',$id)===1;}
function aiProviderDiagnostic(int $http,?array $body,string $model,int $transportError=0):array{
 $error=is_array($body['error']??null)?$body['error']:[];
 $safe=fn($v)=>is_string($v)&&preg_match('/^[a-zA-Z0-9_.:\/-]{1,120}$/',$v)?$v:'';
 $code=$safe($error['code']??'');$type=$safe($error['type']??'');$param=$safe($error['param']??'');
 $category='provider_error';$message='AI sağlayıcısı isteği tamamlayamadı.';
 if($http===0){$category='connection';$message=$transportError===28?'AI bağlantısı zaman aşımına uğradı. Sunucunun bağlantısını kontrol edin; aynı isteği art arda başlatmayın.':'Sunucu OpenAI API bağlantısını kuramadı. PHP cURL, DNS ve HTTPS erişimini kontrol edin.';}
 elseif($http===401){$category='authentication';$message='OpenAI API anahtarı kabul edilmedi. Entegrasyon bağlantılarındaki anahtarı ve ait olduğu projeyi kontrol edin.';}
 elseif($code==='insufficient_quota'||in_array($type,['insufficient_quota','billing_error'],true)||str_contains($code,'billing')){$category='billing';$message='OpenAI API hesabının bakiye veya proje harcama sınırı isteği engelledi. Bu, paneldeki günlük istek sınırı değildir. OpenAI API Billing / Limits bölümünü kontrol edin; ChatGPT aboneliği API bakiyesi sağlamaz.';}
 elseif($code==='model_not_found'||$http===404){$category='model_access';$message='Seçilen model bu API anahtarı için bulunamadı veya erişilebilir değil: '.$model.'. AI ayarlarından hesaptaki modelleri getirip uygun modeli seçin.';}
 elseif($http===403){$category='permission';$message='OpenAI bu işlem için yetki vermedi. API projesinin model/anahtar izinlerini ve gerekiyorsa hesap doğrulamasını kontrol edin.';}
 elseif($http===429){$category='rate_limit';$message='OpenAI API istek/token hız sınırı isteği engelledi. Bir süre sonra tekrar deneyin. Bu, paneldeki günlük istek adedi sınırı değildir.';}
 elseif(in_array($http,[400,413,422],true)&&(in_array($code,['context_length_exceeded','string_above_max_length','prompt_too_long','input_too_long'],true)||($param==='prompt'&&preg_match('/(?:too long|maximum.{0,40}(?:length|character)|length.{0,30}exceed)/i',(string)($error['message']??''))))){$category='input_length';$message='Seçilen OpenAI modeli bu isteğin uzunluğunu kabul etmedi. Uygulama istek veya marka metnini kesmedi. Bu modelin görsel giriş sınırını kontrol edin; göreve özel kuralları düzenleyebilir veya uygun başka bir model seçebilirsiniz.';}
 elseif(in_array($http,[400,422],true)){$category='request';$message='OpenAI istek biçimini veya bir model seçeneğini kabul etmedi. Modelin bu görevi ve seçenekleri desteklediğini kontrol edin.';}
 elseif($http>=500){$category='provider_unavailable';$message='OpenAI hizmetinde geçici bir hata oluştu. Bir süre sonra tekrar deneyin.';}
 elseif($http>=200&&$http<300){$category='invalid_response';$message='OpenAI yanıtı beklenen biçimde okunamadı. Sunucu bağlantısını ve API yanıtını kontrol edin.';}
 $details=array_filter(['HTTP '.$http,$code!==''?'Kod: '.$code:'',$param!==''?'Alan: '.$param:'']);
 return ['category'=>$category,'http'=>$http,'code'=>$code,'type'=>$type,'param'=>$param,'model'=>$model,'message'=>$message.' ('.implode(' · ',$details).')'];
}
function aiProviderRequireCurl():void{if(!function_exists('curl_init'))throw new DomainException('Sunucunun PHP cURL eklentisi etkin değil. OpenAI bağlantısı için hostingde cURL etkinleştirilmeli.');}
function aiProviderModels():array{
 if(envv('OPENAI_API_KEY')==='')throw new DomainException('Önce Entegrasyon bağlantılarından OpenAI API anahtarını kaydedin.');aiProviderRequireCurl();
 $ch=curl_init('https://api.openai.com/v1/models');curl_setopt_array($ch,[CURLOPT_HTTPHEADER=>['Authorization: Bearer '.envv('OPENAI_API_KEY'),'Accept: application/json'],CURLOPT_RETURNTRANSFER=>true,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>30]);
 $raw=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$errno=function_exists('curl_errno')?curl_errno($ch):0;curl_close($ch);$body=json_decode((string)$raw,true);
 if($http<200||$http>=300||!is_array($body['data']??null))throw new AiProviderException(aiProviderDiagnostic($http,is_array($body)?$body:null,'models',$errno));
 $models=[];foreach($body['data'] as $row)if(aiModelIdValid($row['id']??null))$models[]=$row['id'];$models=array_values(array_unique($models));sort($models,SORT_NATURAL);
 return ['models'=>$models,'checkedAt'=>date(DATE_ATOM),'note'=>'API anahtarının görebildiği model kimlikleri. Listede görünmesi her görev/araç için destek veya kullanılabilir bakiye garantisi değildir. Bu kontrol içerik üretmez ve panel istek kotasını kullanmaz.'];
}
function aiModelUsesReasoning(string $id):bool{return preg_match('/^(?:gpt-(?:5|6)(?:[.\-]|$)|o[134](?:[.\-]|$))/',$id)===1;}
