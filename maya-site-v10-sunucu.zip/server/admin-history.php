<?php
declare(strict_types=1);
function historyPageWindow(array $query,int $total,array $sizes):array{
 $size=filter_var($query['size']??10,FILTER_VALIDATE_INT);if(!in_array($size,$sizes,true))$size=10;
 $pages=max(1,(int)ceil($total/$size));$requested=filter_var($query['page']??1,FILTER_VALIDATE_INT);$page=max(1,min($pages,$requested===false?1:$requested));
 return ['total'=>$total,'page'=>$page,'pages'=>$pages,'size'=>$size];
}
function historyDate(mixed $value):string{
 if(!is_string($value))throw new DomainException('Tarih filtresini YYYY-AA-GG biçiminde girin.');$value=trim($value);if($value==='')return '';
 $date=DateTimeImmutable::createFromFormat('!Y-m-d',$value);if(!$date||$date->format('Y-m-d')!==$value)throw new DomainException('Tarih filtresini kontrol edin.');return $value;
}
function auditLogPage(array $query):array{
 $from=historyDate($query['from']??'');$to=historyDate($query['to']??'');if($from!==''&&$to!==''&&$from>$to)throw new DomainException('Başlangıç tarihi bitiş tarihinden sonra olamaz.');
 $where=[];$args=[];if($from!==''){$where[]='created_at >= ?';$args[]=$from;}if($to!==''){$where[]='created_at < ?';$args[]=(new DateTimeImmutable($to))->modify('+1 day')->format('Y-m-d');}$filter=$where?' WHERE '.implode(' AND ',$where):'';
 $total=(int)sql('SELECT COUNT(*) FROM audit_log'.$filter,$args)->fetchColumn();$window=historyPageWindow($query,$total,[10,20,50,100]);$offset=($window['page']-1)*$window['size'];
 $items=sql('SELECT id,user_id,event,created_at FROM audit_log'.$filter.' ORDER BY id DESC LIMIT '.$window['size'].' OFFSET '.$offset,$args)->fetchAll();return $window+['items'=>$items,'filters'=>['from'=>$from,'to'=>$to]];
}
function revisionHistoryPage(array $query):array{
 $total=(int)sql('SELECT COUNT(*) FROM records WHERE kind=?',['revisions'])->fetchColumn();$window=historyPageWindow($query,$total,[10,20,30,50]);$offset=($window['page']-1)*$window['size'];
 $rows=sql('SELECT id,payload,updated_at FROM records WHERE kind=? ORDER BY updated_at DESC,id DESC LIMIT '.$window['size'].' OFFSET '.$offset,['revisions'])->fetchAll();$items=[];
 foreach($rows as $row){$value=json_decode($row['payload'],true,512,JSON_THROW_ON_ERROR);$items[]=['id'=>$row['id'],'kind'=>$value['kind']??'','target'=>$value['target']??'','date'=>$value['date']??$row['updated_at']];}
 return $window+['items'=>$items];
}

function mailQueuePage(array $query):array{
 $size=filter_var($query['size']??5,FILTER_VALIDATE_INT);$query['size']=in_array($size,[5,10,20],true)?$size:5;
 $total=(int)sql('SELECT COUNT(*) FROM mail_queue')->fetchColumn();$window=historyPageWindow($query,$total,[5,10,20]);$offset=($window['page']-1)*$window['size'];
 $items=sql('SELECT id,audience,recipient,subject,status,attempts,created_at FROM mail_queue ORDER BY id DESC LIMIT '.$window['size'].' OFFSET '.$offset)->fetchAll();return $window+['items'=>$items];
}
