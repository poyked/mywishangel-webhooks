<?php
declare(strict_types=1);
// Bütçe tahmini için referans katsayıları; güncel sağlayıcı faturası değildir. Tanımsız modelde ihtiyatlı varsayım kullanılır.
function aiRates(string $model):array{return match($model){'gpt-4.1-mini'=>[0.4,0.1,1.6],'gpt-4.1'=>[2,0.5,8],'gpt-4.1-nano'=>[0.1,0.025,0.4],'gpt-5-mini'=>[0.25,0.025,2],'gpt-5-nano'=>[0.05,0.005,0.4],'gpt-5'=>[1.25,0.125,10],'gpt-6-luna'=>[0.10,0.01,0.50],'gpt-6.1-terra'=>[1,0.05,5],'gpt-6.1-sol'=>[2,0.10,10],'gpt-6-astra'=>[10,1,50],default=>[5,1.25,30]};}
function aiModelCatalog():array{
 $models=[
  ['id'=>'gpt-6-luna','label'=>'GPT-6 Luna','costClass'=>'En ekonomik','purpose'=>'Müşteri sohbeti, kısa metinler ve ilk reklam fikirleri'],
  ['id'=>'gpt-6.1-terra','label'=>'GPT-6.1 Terra','costClass'=>'Ekonomik','purpose'=>'Uzun metinler, belge analizi ve ayrıntılı düzenleme'],
  ['id'=>'gpt-6.1-sol','label'=>'GPT-6.1 Sol','costClass'=>'Dengeli','purpose'=>'Yaratıcı kampanyalar ve daha zor içerik işleri'],
  ['id'=>'gpt-6-astra','label'=>'GPT-6 Astra','costClass'=>'En yüksek maliyet','purpose'=>'Çok karmaşık analiz; rutin işler için önerilmez']
 ];
 foreach($models as &$model){[$input,$cache,$output]=aiRates($model['id']);$model['rates']=['input'=>$input,'cachedInput'=>$cache,'output'=>$output];$model['priceBasis']='Yerel bütçe referansı; güncel sağlayıcı fiyatı doğrulanmadı.';}unset($model);return $models;
}
function aiCost(array $entry):?float{$u=$entry['usage']??[];if(!$u)return !empty($entry['providerRejected'])?0.0:null;$model=$entry['model']??'';if(($entry['task']??'')==='transcription')return ((int)($u['input_tokens']??0)*1.25+(int)($u['output_tokens']??0)*5)/1000000;if(($entry['task']??'')==='image'){$detail=$u['input_tokens_details']??[];$text=(int)($detail['text_tokens']??0);$image=(int)($detail['image_tokens']??0);if(!$text&&!$image)$text=(int)($u['input_tokens']??0);$rates=$model==='gpt-image-1-mini'?[2.5,2.5,8]:[5,8,30];return ($text*$rates[0]+$image*$rates[1]+(int)($u['output_tokens']??0)*$rates[2])/1000000;}
 [$input,$cache,$output]=aiRates($model);$cached=(int)($u['input_tokens_details']['cached_tokens']??0);$total=(int)($u['input_tokens']??0);$cost=(max(0,$total-$cached)*$input+$cached*$cache+(int)($u['output_tokens']??0)*$output)/1000000;return $cost+(int)($entry['searchCalls']??0)*0.01;
}
function aiBudgetState():array{$spent=0;$pending=0;$unknown=0;$daily=0;$voice=0;foreach(records('ai_usage') as $entry){$date=$entry['date']??'';if(str_starts_with($date,date('Y-m-d'))){$daily++;if(($entry['task']??'')==='transcription')$voice++;}if(!str_starts_with($date,date('Y-m')))continue;$cost=aiCost($entry);if($cost!==null)$spent+=$cost;elseif(($entry['status']??'')==='processing'&&strtotime($date)>time()-600)$pending+=(float)($entry['reserved']??0);else{$unknown++;$pending+=(float)($entry['budgetHold']??0);}}return ['estimatedUsd'=>round($spent,8),'pendingUsd'=>round($pending,8),'unknownRequests'=>$unknown,'requestsToday'=>$daily,'voiceRequestsToday'=>$voice,'priceDate'=>'2026-11-04'];}
