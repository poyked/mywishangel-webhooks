<?php
declare(strict_types=1);

function assistantQuestionKey(string $text):string{
 $text=mb_strtolower(strtr($text,['İ'=>'i','I'=>'ı']),'UTF-8');
 return trim(preg_replace('/\s+/u',' ',preg_replace('/[^\pL\pN\s]/u',' ',strtr($text,['ı'=>'i','ş'=>'s','ğ'=>'g','ü'=>'u','ö'=>'o','ç'=>'c']))));
}
function assistantAnswerId(string $question,string $scope,string $productId):string{return hash('sha256',$scope.'|'.$productId.'|'.assistantQuestionKey($question));}
function assistantBrandFingerprint():string{
 $k=aiKnowledge();$s=record('settings','store')??[];$catalog=[];
 foreach(records('products') as $p)$catalog[(string)$p['id']]=array_intersect_key($p,array_flip(['id','name','productType','active','ingredients','allergens','storage','nutrition','description','details','subtitle','shortTitle','tags','weights','verified','items']));ksort($catalog);
 return hash('sha256',jsonval(['version'=>2,'master'=>$k['masterText'],'chatRules'=>$k['taskRules']['chat']??'','notes'=>aiConfig()['extraPrompt']??'','brand'=>assistantBrandFacts($s['assistantBrand']??[]),'productMode'=>$k['productMode']??'all','productIds'=>$k['productIds']??[],'productFacts'=>$k['productFacts']??[],'catalog'=>$catalog]));
}
function assistantAnswerVariables():array{return [
 'kargo_ucreti'=>'Güncel kargo ücreti','ucretsiz_kargo_esigi'=>'Ücretsiz kargo eşiği','kargo_son_saat'=>'Kargoya verme son saati',
 'tahmini_tasima'=>'Tahmini kargo taşıma aralığı','urun_adi'=>'İlgili ürünün adı','urun_fiyati'=>'Güncel ürün / belirtilen gramajın fiyatı',
 'urun_gramaji'=>'Cevabın ürün gramajı','stok'=>'İlgili ürünün güncel stok adedi','kampanyalar'=>'Güncel kampanyalar'
];}
function assistantPublicProduct(array $store,string $id):?array{foreach($store['products']??[] as $p)if(($p['id']??'')===$id)return $p;return null;}
function assistantRenderAnswer(string $text,array $store,string $productId,string $question=''):?string{
 $p=assistantPublicProduct($store,$productId);$s=$store['settings'];$shipping=$s['shipping']??[];$price=$p['price']??null;$stock=$p['stock']??null;$weight=$p?(float)($p['weights'][0]??500):null;
 if($p&&preg_match('/(\d+(?:[.,]\d+)?)\s*(kg|kilogram|gram|gr|g)\b/iu',$question,$weightMatch))$weight=(float)str_replace(',','.',$weightMatch[1])*(in_array(mb_strtolower($weightMatch[2]),['kg','kilogram'],true)?1000:1);
 if($p){
  if(($p['productType']??'single')==='bundle'){if($weight!==(float)($p['weights'][0]??500)){$price=null;$stock=null;}}
  else{$variant=null;foreach($p['variants']??[] as $v)if((float)($v['weight']??0)===$weight){$variant=$v;break;}
   if($variant){$price=$variant['price']??null;$stock=$variant['stock']??null;}
   elseif(in_array($weight,array_map('floatval',$p['weights']??[500]),true))$price=$price!==null?(float)$price*$weight/500:null;
   else{$price=null;$stock=null;}
  }
 }
 $money=fn($v)=>number_format((float)$v,2,',','.').' TL';
 $values=['kargo_ucreti'=>isset($s['shippingFee'])?$money($s['shippingFee']):null,'ucretsiz_kargo_esigi'=>isset($s['freeShipping'])?$money($s['freeShipping']):null,
  'kargo_son_saat'=>$shipping['cutoff']??null,'tahmini_tasima'=>isset($shipping['transitMin'],$shipping['transitMax'])?$shipping['transitMin'].'–'.$shipping['transitMax'].' iş günü (tahmini taşıma süresi)':null,
  'urun_adi'=>$p['name']??null,'urun_gramaji'=>$weight!==null?rtrim(rtrim(number_format($weight,2,',',''),'0'),',').' g':null,'urun_fiyati'=>$price!==null?$money($price):null,'stok'=>$stock!==null?(string)max(0,(int)$stock):null,
  'kampanyalar'=>($store['campaigns']??[])?implode('; ',array_column($store['campaigns'],'title')):'Şu anda yayınlanmış kampanya bulunmuyor.'];
 $missing=false;$result=preg_replace_callback('/\{\{\s*([a-z_]+)\s*\}\}/',function($m)use($values,&$missing){$value=$values[$m[1]]??null;if($value===null)$missing=true;return (string)$value;},$text);
 return $missing?null:$result;
}
function assistantValidateAnswer(string $question,string $answer,string $scope,array $store,string $productId):void{
 if(str_contains(preg_replace('/\{\{\s*[a-z_]+\s*\}\}/','',$answer),'{{')||str_contains(preg_replace('/\{\{\s*[a-z_]+\s*\}\}/','',$answer),'}}'))throw new DomainException('Değişken yazımını kontrol edin; örneğin {{urun_fiyati}}.');
 preg_match_all('/\{\{\s*([^{}]+)\s*\}\}/',$answer,$matches);foreach($matches[1] as $key)if(!array_key_exists(trim($key),assistantAnswerVariables()))throw new DomainException('Bilinmeyen cevap değişkeni: '.$key);
 $q=assistantQuestionKey($question);$a=assistantQuestionKey($answer);
 if(preg_match('/\d[\d.,]*\s*(?:TL\b|₺|USD\b)|₺\s*\d|%\s*\d|\d\s*%/iu',$answer))throw new DomainException('Fiyat ve indirimi sabit rakamla yazmayın. Güncel fiyat/kampanya değişkenlerini kullanın.');
 if(preg_match('/stokta\s+(?:var|yok|mevcut|kalmadi)|tukendi/u',$a))throw new DomainException('Stok durumunu sabitlemeyin. Ürüne özel cevapta Güncel stok: {{stok}} adet biçimini kullanın.');
 if(preg_match('/siparis(?:iniz)? (?:degistirildi|iptal edildi)|iade(?:niz)? (?:baslatildi|yapildi)|talebiniz (?:iletildi|olusturuldu)/u',$a))throw new DomainException('Hazır cevap sipariş veya iade işlemi yapmaz. İşlem tamamlandı iddiası yerine gerçek destek yolunu belirtin.');
 $required=[];if(preg_match('/stok|kac adet|kac tane/u',$q))$required=['stok'];
 elseif(preg_match('/kampanya|indirim/u',$q))$required=['kampanyalar'];
 elseif(preg_match('/fiyat|ucret|bedel|tutar|kac tl/u',$q)||(preg_match('/ne kadar$/u',$q)&&!preg_match('/sure|gun|zaman/u',$q)))$required=str_contains($q,'kargo')?['kargo_ucreti','ucretsiz_kargo_esigi']:['urun_fiyati'];
 if($required&&!array_intersect($required,array_map('trim',$matches[1])))throw new DomainException('Bu sorunun cevabında güncel bilgi değişkeni kullanın: {{'.implode('}} veya {{',$required).'}}.');
 $productVariables=array_intersect(['urun_adi','urun_fiyati','urun_gramaji','stok'],array_map('trim',$matches[1]));
 if($scope==='general'&&$productVariables)throw new DomainException('Ürün değişkenleri için Bu ürün / paket kapsamını seçin.');
 if($scope==='product'&&!assistantPublicProduct($store,$productId))throw new DomainException('Bu ürün artık mağazada yayında değil. Genel kapsam seçin veya ürünü kontrol edin.');
 if(assistantRenderAnswer($answer,$store,$productId,$question)===null)throw new DomainException('Cevaptaki güncel bilgi kaynağı eksik. Ürün veya kargo ayarlarını kontrol edin.');
 $facts=$store['settings']['assistantBrand']??[];
 foreach(['noAdditives'=>['katki maddesi kullanmiyoruz','katki maddesi kullanilir','katki maddesi kullaniyoruz'],'noPreservatives'=>['koruyucu kullanmiyoruz','koruyucu kullanilir','koruyucu kullaniyoruz']] as $flag=>$claims){
  if(($facts[$flag]??false)===false&&str_contains($a,$claims[0]))throw new DomainException('Cevap, kayıtlı marka bilgisiyle çelişiyor. Önce marka bilgisini kontrol edin.');
  if(($facts[$flag]??false)===true&&(str_contains($a,$claims[1])||str_contains($a,$claims[2])))throw new DomainException('Cevap, kayıtlı marka bilgisiyle çelişiyor.');
 }
}
function assistantAnswerRow(string $id,bool $lock=false):?array{
 return sql('SELECT * FROM assistant_answers WHERE id=?'.($lock&&envv('DB_DRIVER')!=='sqlite'?' FOR UPDATE':''),[$id])->fetch()?:null;
}
function assistantAnswerView(array $row,string $brandHash):array{$row['revision']=(int)$row['revision'];$row['needsReview']=$row['state']==='active'&&!hash_equals($brandHash,$row['brand_hash']);return $row;}
function assistantExactAnswer(string $question,string $productId,array $store,string $brandHash):?array{
 foreach($productId!==''?['product','general']:['general'] as $scope){$id=assistantAnswerId($question,$scope,$scope==='product'?$productId:'');$r=assistantAnswerRow($id);
  if(!$r||$r['state']!=='active'||!hash_equals($brandHash,$r['brand_hash']))continue;
  if($scope==='product'&&!assistantPublicProduct($store,$productId))continue;
  $answer=assistantRenderAnswer($r['answer'],$store,$scope==='product'?$productId:'',$question);if($answer===null)continue;
  return ['answer'=>$answer,'source'=>'approved-answer','model'=>'','gpt'=>false,'approvedAnswerId'=>$r['id']];
 }return null;
}
function assistantSearchWords(string $question):array{
 $key=assistantQuestionKey($question);$words=explode(' ',$key);
 foreach(['paketleme'=>'paketle|ambalaj|vakum','teslimat'=>'kargo|teslimat|gonder','koruyucu'=>'koruyucu','katki'=>'katki','dogal'=>'dogal','saklama'=>'sakla|muhafaza'] as $word=>$pattern)if(preg_match('/'.$pattern.'/u',$key))$words[]=$word;
 return array_values(array_unique(array_filter($words,fn($w)=>mb_strlen($w)>=3&&!in_array($w,['nasil','hangi','nedir','urun','urunler','urunleriniz','peynir','peynirler','peynirleriniz','icin','var','olan','olarak'],true))));
}
function assistantRelatedAnswers(string $question,string $productId,array $store,string $brandHash):array{
 $words=array_slice(assistantSearchWords($question),0,10);if(!$words)return [];$where=[];$args=[$brandHash,$productId];
 foreach($words as $w){$where[]="search_text LIKE ? ESCAPE '!'";$args[]='%'.str_replace(['!','%','_'],['!!','!%','!_'],$w).'%';}
 $rows=sql("SELECT * FROM assistant_answers WHERE state='active' AND brand_hash=? AND (scope='general' OR (scope='product' AND product_id=?)) AND (".implode(' OR ',$where).') ORDER BY updated_at DESC LIMIT 40',$args)->fetchAll();$out=[];
 foreach($rows as $r){$own=assistantSearchWords($r['question']);$overlap=count(array_intersect($own,$words));if(!$overlap)continue;if($r['scope']==='product'&&!assistantPublicProduct($store,$productId))continue;$text=assistantRenderAnswer($r['answer'],$store,$r['scope']==='product'?$productId:'',$r['question']);if($text===null)continue;
  $out[]=['id'=>$r['id'],'question'=>$r['question'],'answer'=>$text,'scope'=>$r['scope'],'revision'=>(int)$r['revision'],'score'=>$overlap/max(1,count(array_unique(array_merge($own,$words))))];
 }usort($out,fn($a,$b)=>$b['score']<=>$a['score']);return array_map(function($r){unset($r['score']);return $r;},array_slice($out,0,3));
}
function assistantRecordMessage(string $question,string $page,array $context,array $result,string $state='answered'):?string{
 try{
  if(empty($_SESSION['maya_chat_thread'])||!preg_match('/^[a-f0-9]{32}$/',(string)$_SESSION['maya_chat_thread']))$_SESSION['maya_chat_thread']=bin2hex(random_bytes(16));
  $p=$context['product']??null;$answer=(string)($result['answer']??'');$staff=in_array(user()['role']??'',['owner','editor','operations'],true);
  sql('INSERT INTO assistant_messages(conversation_id,question,answer,search_text,route,product_id,product_name,source,model,status,review_status,approved_answer_id,created_at,staff_test) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',[
   $_SESSION['maya_chat_thread'],$question,$answer,assistantQuestionKey($question.' '.$answer),$page,$p['id']??'',$p['name']??'',(string)($result['source']??'error'),(string)($result['model']??''),$state,($result['source']??'')==='approved-answer'?'reviewed':'new',$result['approvedAnswerId']??'',date(DATE_ATOM),$staff?1:0]);
  return (string)db()->lastInsertId();
 }catch(Throwable $e){logError($e);return null;}
}
function assistantSafeHistory(mixed $history):array{
 $out=[];foreach(array_slice(is_array($history)?$history:[],-8) as $m)if(is_array($m)&&in_array($m['role']??'',['user','assistant'],true)&&is_string($m['text']??null))$out[]=['role'=>$m['role'],'text'=>mb_substr($m['text'],0,4000)];return $out;
}
function assistantGenerateReply(string $question,array $store,array $context,array $history):array{
 $q=mb_strtolower($question,'UTF-8');$productId=(string)($context['product']['id']??'');$brandHash=assistantBrandFingerprint();
 if($approved=assistantExactAnswer($question,$productId,$store,$brandHash))return $approved;
 if(preg_match('/hangi (sayfa|ürün)|neredeyim|hangi üründeyim/u',$q))return ['answer'=>$context['product']?$context['product']['name'].' ürün sayfasındasınız. Bu ürünün açıklaması, gramajları ve teslimat bilgileri hakkında yardımcı olabilirim.':'Şu an mağazanın '.($context['route']??'ana sayfa').' bölümündesiniz.','source'=>'page-context','gpt'=>false];
 if($reply=assistantPackagingReply($q,$store['settings']['assistantBrand']))return ['answer'=>$reply,'source'=>'store-packaging','gpt'=>false];
 $brandReply=assistantBrandReply($q,$store['settings']['assistantBrand']);$config=aiConfig();if($brandReply!==null&&(!$config['enabled']||aiKnowledge()['masterText']===''))return ['answer'=>$brandReply,'source'=>'brand-records','gpt'=>false];
 $ready=['peynir cesitleri neler','guncel kampanyalar var mi','kargo ucreti ne kadar','ne zaman kargoya verilir','nasil paketleniyor'];$key=assistantQuestionKey($q);
 if($config['enabled']&&!in_array($key,$ready,true)){
  $safe=$store;$safe['currentPage']=$context;$safe['brandFacts']=$store['settings']['assistantBrand'];$safe['conversation']=$history;$safe['approvedAnswers']=assistantRelatedAnswers($question,$productId,$store,$brandHash);unset($safe['csrf'],$safe['customer'],$safe['googleClientId'],$safe['googleNonce']);
  $cacheId=hash('sha256','maya-chat-reviewed-v1|'.$brandHash.'|'.$question.'|'.jsonval($safe));$cached=record('ai_cache',$cacheId);
  if($cached&&($cached['expires']??0)>time())return ['answer'=>$cached['text'],'source'=>'ai-cache','gpt'=>true,'model'=>$cached['model']??$config['chatModel']];
  $r=aiCall('chat',$question,$safe);put('ai_cache',$cacheId,['text'=>$r['text'],'model'=>$r['model'],'expires'=>time()+3600]);return ['answer'=>$r['text'],'source'=>'ai','gpt'=>true,'model'=>$r['model']];
 }
 $s=$store['settings'];$fallback='Bu konuda henüz doğrulanmış bilgi girilmedi. İletişim bölümünden bize ulaşabilirsiniz.';$answer=$fallback;
 if(str_contains($key,'kampanya')||str_contains($key,'indirim'))$answer=$store['campaigns']?implode("\n",array_column($store['campaigns'],'title')):'Şu anda yayınlanmış kampanya bulunmuyor.';
 elseif(str_contains($key,'ucret')||str_contains($key,'bedel'))$answer='Kargo ücreti: '.$s['shippingFee'].' TL. Ücretsiz kargo eşiği: '.$s['freeShipping'].' TL.';
 elseif(str_contains($key,'peynir')||str_contains($key,'urun'))$answer=implode(', ',array_column($store['products'],'name'));
 elseif(str_contains($key,'kargo')||str_contains($key,'gonderim'))$answer='Kargoya verme son saati: '.($s['shipping']['cutoff']??'Belirtilmedi').'. Tahmini teslimat aralığı ürün ve ödeme sayfasında gösterilir.';
 return ['answer'=>$answer,'source'=>$answer===$fallback?'unanswered':'store-records','gpt'=>false];
}
function assistantServeRequest(array $d):void{
 $question=$d['question']??'';if(!is_string($question)||trim($question)===''||mb_strlen($question)>4000)throw new DomainException('Sorunuzu 1–4000 karakter arasında yazın.');$question=trim($question);
 $page=is_string($d['page']??null)?mb_substr($d['page'],0,180):'';if(!preg_match('~^[a-zA-Z0-9_/-]*$~',$page))$page='';[$type,$id]=array_pad(explode('/',$page,2),2,'');$store=publicStore();$product=in_array($type,['urun','paket'],true)?assistantPublicProduct($store,$id):null;$context=['route'=>$type,'product'=>$product];
 try{$result=assistantGenerateReply($question,$store,$context,assistantSafeHistory($d['history']??[]));}
 catch(Throwable $e){assistantRecordMessage($question,$page,$context,['answer'=>$e instanceof DomainException?$e->getMessage():'Yanıt hazırlanamadı. Lütfen tekrar deneyin.','source'=>'error'],'error');throw $e;}
 $messageId=assistantRecordMessage($question,$page,$context,$result);respond($result+['messageId'=>$messageId,'conversationId'=>$_SESSION['maya_chat_thread']??null]);
}

function assistantPanelAdmin():array{$u=admin();if(!in_array($u['role'],['owner','editor'],true))respond(['error'=>'Asistan konuşmaları için içerik yönetimi yetkisi gerekli.'],403);return $u;}
function assistantPanelProducts():array{
 return sql("SELECT product_id AS id,MAX(product_name) AS name FROM assistant_messages WHERE product_id<>'' GROUP BY product_id ORDER BY name")->fetchAll();
}
function assistantListPage(array $query,bool $answers=false):array{
 $from=historyDate($query['from']??'');$to=historyDate($query['to']??'');if($from!==''&&$to!==''&&$from>$to)throw new DomainException('Başlangıç tarihi bitiş tarihinden sonra olamaz.');
 $table=$answers?'assistant_answers':'assistant_messages';$date=$answers?'updated_at':'created_at';$where=[];$args=[];
 if($from!==''){$where[]=$date.' >= ?';$args[]=$from;}if($to!==''){$where[]=$date.' < ?';$args[]=(new DateTimeImmutable($to))->modify('+1 day')->format('Y-m-d');}
 $term=$query['q']??'';if(!is_string($term)||mb_strlen($term)>200)throw new DomainException('Arama metni en fazla 200 karakter olabilir.');$term=assistantQuestionKey($term);if($term!==''){$where[]="search_text LIKE ? ESCAPE '!'";$args[]='%'.str_replace(['!','%','_'],['!!','!%','!_'],$term).'%';}
 $product=$query['product']??'';if(!is_string($product)||mb_strlen($product)>100)throw new DomainException('Ürün filtresi geçersiz.');if($product!==''){$where[]='product_id=?';$args[]=$product;}
 $state=(string)($query['state']??'');$brandHash=assistantBrandFingerprint();
 if($answers){if(!in_array($state,['','active','draft','paused','stale'],true))throw new DomainException('Cevap durumu geçersiz.');if($state==='stale'){$where[]="state='active' AND brand_hash<>?";$args[]=$brandHash;}elseif($state==='active'){$where[]="state='active' AND brand_hash=?";$args[]=$brandHash;}elseif($state!==''){$where[]='state=?';$args[]=$state;}}
 else{
  if(!in_array($state,['','new','reviewed','corrected'],true))throw new DomainException('İnceleme durumu geçersiz.');if($state!==''){$where[]='review_status=?';$args[]=$state;}
  $source=(string)($query['source']??'');$sources=['ai'=>['ai','ai-cache'],'ready'=>['store-records','store-packaging','brand-records','page-context'],'approved'=>['approved-answer'],'error'=>['error'],'unanswered'=>['unanswered']];if($source!==''&&!isset($sources[$source]))throw new DomainException('Cevap kaynağı geçersiz.');if($source!==''){$where[]='source IN ('.implode(',',array_fill(0,count($sources[$source]),'?')).')';array_push($args,...$sources[$source]);}
  $thread=$query['conversation']??'';if(!is_string($thread)||($thread!==''&&!preg_match('/^[a-f0-9]{32}$/',$thread)))throw new DomainException('Konuşma filtresi geçersiz.');if($thread!==''){$where[]='conversation_id=?';$args[]=$thread;}
 }
 $filter=$where?' WHERE '.implode(' AND ',$where):'';$total=(int)sql('SELECT COUNT(*) FROM '.$table.$filter,$args)->fetchColumn();$window=historyPageWindow($query,$total,[10,20,50,100]);$offset=($window['page']-1)*$window['size'];
 $items=sql('SELECT * FROM '.$table.$filter.' ORDER BY '.$date.' DESC,id DESC LIMIT '.$window['size'].' OFFSET '.$offset,$args)->fetchAll();
 foreach($items as &$item){if($answers)$item=assistantAnswerView($item,$brandHash);foreach(['question','answer'] as $key)$item[$key]=mb_substr($item[$key],0,320);unset($item['search_text']);}unset($item);
 return $window+['items'=>$items,'products'=>assistantPanelProducts(),'canApprove'=>admin()['role']==='owner'];
}
function assistantSaveAnswer(array $d):array{
 $u=assistantPanelAdmin();$state=$d['state']??'draft';if(!in_array($state,['draft','active','paused'],true))throw new DomainException('Cevap durumu geçersiz.');if($state==='active')owner();
 $turn=sql('SELECT * FROM assistant_messages WHERE id=?',[(int)($d['messageId']??0)])->fetch();$existing=!empty($d['id'])?assistantAnswerRow((string)$d['id']):null;
 if(!$turn&&!$existing)respond(['error'=>'Konuşma veya cevap bulunamadı.'],404);
 if($existing&&$turn&&assistantQuestionKey($existing['question'])!==assistantQuestionKey($turn['question']))throw new DomainException('Cevap bu konuşmanın sorusuyla eşleşmiyor.');
 $question=$existing['question']??$turn['question'];$scope=$d['scope']??($existing['scope']??'general');if(!in_array($scope,['general','product'],true))throw new DomainException('Cevap kapsamı geçersiz.');
 $productId=$scope==='product'?(string)($existing['product_id']??$turn['product_id']):'';if($scope==='product'&&$productId==='')throw new DomainException('Bu konuşma bir ürün sayfasından gelmiyor; genel kapsamı seçin.');
 $id=assistantAnswerId($question,$scope,$productId);if($existing&&$id!==$existing['id'])throw new DomainException('Kayıtlı cevabın kapsamı değiştirilemez. Konuşmadan ayrı bir cevap hazırlayın.');
 $answer=$d['answer']??'';if(!is_string($answer)||trim($answer)===''||mb_strlen($answer)>6000)throw new DomainException('Cevap 1–6000 karakter arasında olmalı.');$answer=trim($answer);
 $revision=filter_var($d['revision']??0,FILTER_VALIDATE_INT);if($revision===false||$revision<0)throw new DomainException('Cevap sürümü geçersiz.');
 $hash=assistantBrandFingerprint();if($state==='active'){if(!is_string($d['brandRevision']??null)||!hash_equals($hash,$d['brandRevision']))respond(['error'=>'Marka veya ürün bilgileri bu pencere açıldıktan sonra değişti. Cevabı yeniden açıp güncel kurallarla onaylayın.'],409);assistantValidateAnswer($question,$answer,$scope,publicStore(),$productId);}
 db()->beginTransaction();try{
  $old=assistantAnswerRow($id,true);if((int)($old['revision']??0)!==$revision)respondAssistantConflict();
  $now=date(DATE_ATOM);$values=[$question,assistantQuestionKey($question),$scope,$productId,(string)($existing['product_name']??$turn['product_name']??''),$answer,assistantQuestionKey($question.' '.implode(' ',assistantSearchWords($question)).' '.$answer),$state,$hash,$revision+1,(int)$u['id'],$now];
  if($old)sql('UPDATE assistant_answers SET question=?,question_key=?,scope=?,product_id=?,product_name=?,answer=?,search_text=?,state=?,brand_hash=?,revision=?,updated_by=?,updated_at=? WHERE id=?',array_merge($values,[$id]));
  else sql('INSERT INTO assistant_answers(question,question_key,scope,product_id,product_name,answer,search_text,state,brand_hash,revision,updated_by,updated_at,id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)',array_merge($values,[$id,$now]));
  if($turn)sql('UPDATE assistant_messages SET review_status=?,approved_answer_id=? WHERE id=?',[$state==='active'?'corrected':'reviewed',$id,$turn['id']]);
  audit('assistant.answer.'.$state,['id'=>$id,'revision'=>$revision+1,'scope'=>$scope]);db()->commit();return assistantAnswerView(assistantAnswerRow($id),$hash);
 }catch(Throwable $e){if(db()->inTransaction())db()->rollBack();throw $e;}
}
function respondAssistantConflict():never{if(db()->inTransaction())db()->rollBack();respond(['error'=>'Bu cevap başka bir pencerede değişti. Yeniden açıp düzenleyin.'],409);}
function assistantConversationRoutes(string $route,string $method):void{
 if($route==='assistant-conversations'){assistantPanelAdmin();respond(assistantListPage($_GET));}
 if($route==='assistant-answers'){assistantPanelAdmin();respond(assistantListPage($_GET,true));}
 if($route==='assistant-conversation'){
  assistantPanelAdmin();$row=sql('SELECT * FROM assistant_messages WHERE id=?',[(int)($_GET['id']??0)])->fetch();if(!$row)respond(['error'=>'Konuşma bulunamadı.'],404);unset($row['search_text']);$hash=assistantBrandFingerprint();$answers=[];
  foreach($row['product_id']!==''?['general','product']:['general'] as $scope){$r=assistantAnswerRow(assistantAnswerId($row['question'],$scope,$scope==='product'?$row['product_id']:''));$answers[$scope]=$r?assistantAnswerView($r,$hash):null;}
  respond(['message'=>$row,'answers'=>$answers,'variables'=>assistantAnswerVariables(),'brandRevision'=>$hash,'canApprove'=>admin()['role']==='owner']);
 }
 if($route==='assistant-answer'){assistantPanelAdmin();$r=assistantAnswerRow((string)($_GET['id']??''));if(!$r)respond(['error'=>'Cevap bulunamadı.'],404);$hash=assistantBrandFingerprint();respond(['answer'=>assistantAnswerView($r,$hash),'variables'=>assistantAnswerVariables(),'brandRevision'=>$hash,'canApprove'=>admin()['role']==='owner']);}
 if($route==='assistant-answer-save'&&$method==='POST'){assistantPanelAdmin();respond(['answer'=>assistantSaveAnswer(input())]);}
 if($route==='assistant-conversation-review'&&$method==='POST'){
  assistantPanelAdmin();$d=input();$state=$d['state']??'reviewed';if(!in_array($state,['new','reviewed'],true))throw new DomainException('İnceleme durumu geçersiz.');$id=(int)($d['id']??0);if(!sql('SELECT id FROM assistant_messages WHERE id=?',[$id])->fetchColumn())respond(['error'=>'Konuşma bulunamadı.'],404);
  sql('UPDATE assistant_messages SET review_status=? WHERE id=?',[$state,$id]);audit('assistant.message.review',['id'=>$id,'state'=>$state]);respond(['ok'=>true]);
 }
}
