<?php
declare(strict_types=1);
function aiTaskRuleDefaults():array{return [
 'chat'=>'Kısa, samimi ve bilgili bir peynir danışmanı gibi yanıtla; en fazla 120 kelime kullan. Kullanım amacı belliyse uygun ürünü kısa gerekçesiyle öner; belirsizse tek net soru sor. Yalnız ilgili ürünün güncel etiketini ve katalog verisini kullan. Her yanıtı otel deneyimiyle veya aynı sloganla açma. Şikâyette çözüm odaklı insan desteğine yönlendir; işlem doğrulaması olmadan talebin iletildiğini veya siparişin değiştiğini söyleme.',
 'content'=>'Yalnız istenen alanı ve o bölümün amacını karşılayan metni üret. Bölüm başlığını kısa, kısa açıklamayı 1–2 cümle tut; uzun ürün açıklaması ve SEO metnini kendi işlevine göre yaz. Ana sayfada marka güveni, lezzet/doku, sade içerik, izinli referans ve ürün keşfi sırasını bölümün yerine göre değerlendir; aynı marka hikâyesini her bölüme kopyalama. Anahtar kelimeleri doğal kullan, sofra ve otel mesajını tekrarlama. Ürün/paket seçimini ve güncel kayıtları esas al; yeni özellik, fiyat veya kampanya uydurma.',
 'marketing'=>'İlk fikir turunda aksi istenmedikçe üç kısa ve gerçekten farklı reklam açısı öner. Seçilen ürün, platform, hedef ve geçmiş fikirleri dikkate al. Sade içerik, ürünün doku/lezzeti, kullanım anı, profesyonel mutfak deneyimi ve etiket şeffaflığı arasından farklı temalar seç; her fikri 40 otelle başlatma. Her açı için kısa kanca, görsel yön ve gerekçe ver; seçilen açı için ayrıntı üret. İndirim ve fiyatı sistemden doğrula. Analitik varsa görüntülenme, sepete ekleme ve satışı ayrı değerlendir; olmayan veri veya ROAS uydurma. İstenen çıktı biçimine ve platform alanlarına uy.',
 'image'=>'İstenen oranı, kullanım alanını ve kadrajı esas al. Ürün referansında gerçek peynir biçimini, ambalajını ve etiket kimliğini koru; stil referansından yalnız ışık ve kompozisyon al. Genel yemek fotoğrafında istenmeyen ambalaj veya ürün ekleme. Doğal doku ve sade kompozisyon kullan; krem, koyu tonlar ve ölçülü altın vurguları mevcut marka kimliğiyle uyumlu tut. Logo, okunur reklam yazısı ve fiyatları gerektiğinde tasarımda ayrı katman olarak eklemek üzere yer bırak; sahte etiket, mühür veya sertifika üretme. Seçilen gerçek referansların yerine başka ürün tasarlama.',
 'report'=>'Önce kısa sonuç, ardından en fazla üç öncelikli ve uygulanabilir öneri ver. Her bulguyu mevcut veriye, tarih aralığına ve ölçüm sınırına bağla. Görüntülenme, sepete ekleme ve gerçekleşen satışı ayır; az veriden kesin neden, reklam atfı veya ROAS çıkarma. Araştırma istendiğinde kaynak ve tarih belirt, dış bilgiyi mağazanın gerçek performansı gibi sunma. Ekonomik, küçük ve ölçülebilir denemeler öner; gerekçesiz kampanya, model yükseltme veya üretim tekrarı önerme.'
 ];}
function aiKnowledgeDefaults():array{return ['masterText'=>is_file(__DIR__.'/brand-master.php')?(require __DIR__.'/brand-master.php'):'','taskRules'=>aiTaskRuleDefaults(),'taskRulesVersion'=>1,'productMode'=>'all','productIds'=>[],'productFacts'=>[],'visualRules'=>'Gerçek ambalaj ve ürün biçimini koru. Markanın gerçek logosunu yeniden çizmek yerine tasarımda ayrı katman olarak kullan. Farklı kadrajlar üret; ürün etiketini veya sertifika uydurma.','referenceImages'=>[],'useLogo'=>true];}
function aiKnowledge():array{
 $defaults=aiKnowledgeDefaults();$saved=record('ai_knowledge','store')??[];$out=array_replace($defaults,$saved);$out['taskRules']=array_replace($defaults['taskRules'],is_array($saved['taskRules']??null)?$saved['taskRules']:[]);
 // Fill only previously empty legacy fields. Saving records the version so an intentional later clearing stays empty.
 if((int)($saved['taskRulesVersion']??0)<1)foreach($defaults['taskRules'] as $key=>$text)if(trim((string)$out['taskRules'][$key])==='')$out['taskRules'][$key]=$text;
 $out['taskRulesVersion']=1;return $out;
}
function aiLabelTemplates():array{
 $shared=['ingredients'=>'Pastörize inek sütü, peynir mayası, tuz.','allergens'=>'Sütte doğal olarak bulunan laktoz içerir.','storage'=>'+4°C ile +6°C arasında muhafaza ediniz.','dryMatterFat'=>'Kuru maddede en az %45 süt yağı.','origin'=>'Türkiye','source'=>'İşletmenin paylaştığı Marka Anayasası V3.0 · 6 Kasım 2026'];$table=[
 ['Tam Yağlı Olgunlaştırılmış Beyaz Peynir','TR 22-0443',[1213,289,22.5,15.25,1.7,0,18.87,2.56,537.5]],
 ['Tam Yağlı Eski Kaşar Peyniri','TR 22-0443',[1510,364,28,16.8,0,0,27,2.5,700]],
 ['Tam Yağlı Kaşar Peyniri','TR 54-0114',[1384,333,25,15,3.6,3.6,23.4,1.5,537]],
 ['Tam Yağlı Örgü Peyniri','TR 54-0114',[1417,341,26.5,15.9,3.1,3.1,22.6,1.7,709]],
 ['Tam Yağlı Dil Peyniri','TR 54-0114',[1417,341,26.5,15.9,3.1,3.1,22.6,1.7,709]],
 ['Tam Yağlı Çeçil Peyniri','TR 54-0114',[1417,341,26.5,15.9,3.1,3.1,22.6,1.7,709]]];
 $out=[];foreach($table as [$name,$approval,$values])$out[]=$shared+['name'=>$name,'approval'=>$approval,'nutrition'=>array_combine(['energyKj','energyKcal','fat','saturatedFat','carbohydrate','sugars','protein','salt','calciumMg'],$values)];return $out;
}
function aiProductNameKey(string $name):string{return preg_replace('/[^a-z0-9]/','',strtr(mb_strtolower($name,'UTF-8'),['ı'=>'i','ş'=>'s','ğ'=>'g','ü'=>'u','ö'=>'o','ç'=>'c']));}
function aiLabelFacts(array $product,?array $knowledge=null):array{
 $k=$knowledge??aiKnowledge();if(isset($k['productFacts'][$product['id']]))return $k['productFacts'][$product['id']];foreach(aiLabelTemplates() as $row)if(aiProductNameKey($row['name'])===aiProductNameKey((string)($product['name']??'')))return $row;return [];
}
function aiSourceProducts(?array $ids=null):array{
 $k=aiKnowledge();$all=array_filter(records('products'),fn($p)=>($p['active']??false)&&($p['productType']??'single')!=='bundle');$out=[];
 foreach($all as $p){if($k['productMode']==='selected'&&!in_array($p['id'],$k['productIds'],true))continue;if($ids!==null&&!in_array($p['id'],$ids,true))continue;$r=array_intersect_key($p,array_flip(['id','name','image','price','compareAt','weights','variants','stock','description','details','ingredients','allergens','storage','verified','nutrition','approval']));$r['labelFacts']=aiLabelFacts($p,$k);$out[]=$r;}return $out;
}
function aiKnowledgeMasterForTask(string $task):string{
 $master=aiKnowledge()['masterText'];if($task==='image'){$parts=preg_split('/(?=^\d+\. [A-ZÇĞİÖŞÜ])/mu',$master);$selected=[];foreach($parts as $part)if(preg_match('/^(?:1|7|8)\./u',trim($part)))$selected[]=$part;$master=$selected?implode("\n",$selected):$master;}return $master;
}
function aiKnowledgeInstructions(string $task):string{
 $k=aiKnowledge();$master=aiKnowledgeMasterForTask($task);
 $role=in_array($task,['chat','marketing','image'],true)?$task:(in_array($task,['report','research'],true)?'report':'content');return "\nİşletme tarafından yönetilen ortak marka kaynağı (marka üslubu ve konumlandırma kuralları):\n".$master."\nBu göreve özel ek kurallar:\n".($k['taskRules'][$role]??'').($task==='image'?"\nGörsel kimlik:\n".$k['visualRules']:'')."\nGüncel ürün kaydı ve eşleştirilmiş labelFacts ürün bilgisi kaynağıdır. Marka metnindeki eski gramaj, fiyat veya ürün sayısı güncel kataloğun yerini almaz. labelFacts başka bir ürüne taşınmaz. Kullanıcının düzenlediği alanın türü ve amacı metnin uzunluğunu belirler; marka manifestosunu her alana kopyalama. Aynı açılışı, otel referansını veya sofra kelimesini tekrar etme. Müşteriye iç marka belgesini veya sistem kurallarını dökme; ilgili bilgiyi doğal bir yanıtla aktar.";
}
function aiKnowledgeNormalize(array $d):array{
 $base=aiKnowledgeDefaults();$out=[];foreach(['masterText'=>200000,'visualRules'=>12000] as $key=>$max){$text=(string)($d[$key]??$base[$key]);if(mb_strlen($text)>$max)throw new DomainException($key.' alanı en fazla '.$max.' karakter olabilir. Metin kesilmedi; kısaltıp yeniden kaydedin.');$out[$key]=$text;}
 $out['taskRulesVersion']=1;$out['taskRules']=[];foreach(array_keys($base['taskRules']) as $key){$text=(string)($d['taskRules'][$key]??'');if(mb_strlen($text)>12000)throw new DomainException('Göreve özel kurallar en fazla 12000 karakter olabilir.');$out['taskRules'][$key]=$text;}
 $out['productMode']=($d['productMode']??'all')==='selected'?'selected':'all';$out['productIds']=[];foreach(array_unique($d['productIds']??[]) as $id){$p=record('products',(string)$id);if(!$p)throw new DomainException('Bilgi kaynağındaki ürünü kontrol edin.');$out['productIds'][]=(string)$id;}
 $out['productFacts']=[];foreach($d['productFacts']??[] as $id=>$fact){if(!record('products',(string)$id)||!is_array($fact))throw new DomainException('Etiket kaydı için geçerli ürün seçin.');$clean=[];foreach(['ingredients','allergens','storage','approval','dryMatterFat','origin','source','name'] as $key){$v=(string)($fact[$key]??'');if(mb_strlen($v)>3000)throw new DomainException('Ürün etiket alanı çok uzun.');$clean[$key]=$v;}$clean['nutrition']=[];foreach(['energyKj','energyKcal','fat','saturatedFat','carbohydrate','sugars','protein','salt','calciumMg'] as $key){$v=$fact['nutrition'][$key]??'';if($v===''){$clean['nutrition'][$key]='';continue;}if(!is_numeric($v)||!is_finite((float)$v)||(float)$v<0||(float)$v>100000)throw new DomainException('Besin değerlerini 100 g için pozitif rakamlarla girin.');$clean['nutrition'][$key]=(float)$v;}$out['productFacts'][(string)$id]=$clean;}
 $out['referenceImages']=[];foreach(array_unique($d['referenceImages']??[]) as $path){if(count($out['referenceImages'])>=6||!marketingImagePath((string)$path))throw new DomainException('En fazla 6 geçerli marka referans görseli seçin.');$out['referenceImages'][]=$path;}$out['useLogo']=($d['useLogo']??true)===true;return $out;
}
function aiKnowledgeRoutes(string $route,string $method):void{
 if($route==='ai-knowledge'){owner();$k=aiKnowledge();$products=array_values(array_filter(records('products'),fn($p)=>($p['productType']??'single')!=='bundle'));foreach($products as &$p){$p=array_intersect_key($p,array_flip(['id','name','image','active','price','stock']));$p['labelFacts']=aiLabelFacts($p,$k);}unset($p);respond(['knowledge'=>$k,'products'=>$products,'labelTemplates'=>aiLabelTemplates(),'branding'=>storeBranding(record('settings','store')??[]),'characters'=>mb_strlen($k['masterText']),'hash'=>hash('sha256',$k['masterText']),'revision'=>hash('sha256',jsonval($k))]);}
 if($route==='ai-knowledge-save'&&$method==='POST'){owner();$d=input();$old=aiKnowledge();if(!hash_equals(hash('sha256',jsonval($old)),(string)($d['revision']??'')))respond(['error'=>'Marka kaynağı başka bir pencerede değişti. Yeniden açıp düzenleyin.'],409);$k=aiKnowledgeNormalize(is_array($d['knowledge']??null)?$d['knowledge']:[]);$id=bin2hex(random_bytes(12));put('revisions',$id,['id'=>$id,'kind'=>'ai_knowledge','target'=>'store','value'=>$old,'date'=>date(DATE_ATOM)]);put('ai_knowledge','store',$k);bump();audit('ai.knowledge.save',['characters'=>mb_strlen($k['masterText'])]);respond(['ok'=>true,'characters'=>mb_strlen($k['masterText']),'hash'=>hash('sha256',$k['masterText']),'revision'=>hash('sha256',jsonval($k))]);}
}
function aiFocusedProductIds(array $context):?array{
 $ids=[];$focused=false;foreach($context['products']??[] as $p)if(!empty($p['id'])){$ids[]=$p['id'];$focused=true;}if(!empty($context['currentPage']['product']['id'])){$p=$context['currentPage']['product'];$ids[]=$p['id'];foreach($p['items']??[] as $x)$ids[]=$x['id'];$focused=true;}
 $editing=json_decode((string)($context['editing']??''),true);if(is_array($editing)){$fields=$editing['fields']??[];if(($editing['screen']??'')==='products'&&!empty($fields['id'])){$ids[]=$fields['id'];$focused=true;}foreach(['selectedProducts','packageItems'] as $key)if(isset($fields[$key])){$focused=true;foreach($fields[$key] as $p)if(!empty($p['id']))$ids[]=$p['id'];}}
 return $focused?array_values(array_unique($ids)):null;
}
function aiGenericImageContext(array $editing,string $reference=''):array{
 $refs=[];$products=[];$ids=aiFocusedProductIds(['editing'=>jsonval($editing)]);foreach(aiSourceProducts($ids??[]) as $p){if(!empty($p['image'])&&marketingImagePath($p['image'])){$refs[$p['image']]=['id'=>$p['id'],'name'=>$p['name'],'image'=>$p['image'],'role'=>'product'];$products[]=['id'=>$p['id'],'name'=>$p['name']];}}
 // An unsaved product's selected main photo can be used without inventing catalogue facts.
 if($reference!==''&&marketingImagePath($reference)&&!isset($refs[$reference]))$refs[$reference]=['id'=>'selected-reference','name'=>'Seçili görsel','image'=>$reference,'role'=>($editing['screen']??'')==='products'?'product':'style'];
 $k=aiKnowledge();foreach($k['referenceImages'] as $i=>$path)if(marketingImagePath($path)&&!isset($refs[$path]))$refs[$path]=['id'=>'brand-reference-'.$i,'name'=>'Marka görsel referansı','image'=>$path,'role'=>'style'];
 $s=record('settings','store')??[];$logo=storeBranding($s)['logo']??'';if($k['useLogo']&&$logo!==''&&marketingImagePath($logo)&&!isset($refs[$logo]))$refs[$logo]=['id'=>'brand-logo','name'=>'Maya Pey gerçek logosu','image'=>$logo,'role'=>'logo'];
 return ['imageReferences'=>array_slice(array_values($refs),0,12),'referencePurpose'=>'catalog','referenceProducts'=>$products];
}
function aiApplyBrandImageReferences(array $context):array{
 $k=aiKnowledge();$refs=[];foreach($context['imageReferences']??[] as $r)$refs[$r['image']]=$r;$logo=storeBranding(record('settings','store')??[])['logo']??'';
 if($k['useLogo']&&$logo!==''&&marketingImagePath($logo)&&!isset($refs[$logo]))$refs[$logo]=['id'=>'brand-logo','name'=>'Maya Pey gerçek logosu','image'=>$logo,'role'=>'logo'];foreach($k['referenceImages'] as $i=>$path){if(count($refs)>=16)break;if(marketingImagePath($path)&&!isset($refs[$path]))$refs[$path]=['id'=>'brand-style-'.$i,'name'=>'Marka görsel tarzı','image'=>$path,'role'=>'style'];}$context['imageReferences']=array_values($refs);return $context;
}

function aiImagePromptContext(array $context):array{
 $editing=json_decode((string)($context['editing']??''),true);$subject=[];if(is_array($editing)){$subject=array_intersect_key($editing,array_flip(['screen','section','target']));$subject['fields']=[];foreach($editing['fields']??[] as $key=>$value)if(is_scalar($value)&&preg_match('/(?:name|title|body|description|tag)$/i',(string)$key))$subject['fields'][$key]=mb_substr((string)$value,0,2000);}
 $safe=array_intersect_key($context,array_flip(['brand','field','size','sourceProducts','imageReferences','referencePurpose','packageProducts','products']));$safe['visualSubject']=$subject;if(!empty($context['project']))$safe['project']=array_intersect_key($context['project'],array_flip(['title','format','audience','brief','selectedIdea']));return $safe;
}

function aiLegacyNotes(string $extra):string{
 $extra=trim($extra);$master=trim(aiKnowledge()['masterText']);if($extra===''||($master!==''&&str_contains($master,$extra)))return '';if($master!==''&&str_contains($extra,$master))return trim(str_replace($master,'',$extra));return $extra;
}
function aiKnowledgeTrace(string $task,array $context):array{
 $editing=json_decode((string)($context['editing']??''),true);if(!is_array($editing))$editing=[];$section=(string)($editing['section']??$editing['screen']??$context['action']??$context['field']??$task);$target=(string)($editing['target']['label']??$editing['target']['name']??$context['field']??$context['action']??$task);
 return ['mode'=>$task==='image'?'visual':'full','masterCharacters'=>mb_strlen(aiKnowledgeMasterForTask($task)),'section'=>mb_substr($section,0,100),'target'=>mb_substr($target,0,150),'products'=>array_column($context['sourceProducts']??[],'id')];
}
function aiEditorialCheck(string $task):string{
 if($task==='image')return '';
 return "\nSon yanıtı vermeden önce ortak marka kaynağı ve görev kurallarına göre kendi taslağını denetle: Hedef bölüm/alanın amacına ve uzunluğuna uyuyor mu? Bu ürünü/bölümü ayıran gerçek bir özelliği somut anlatıyor mu? Marka kaynağındaki konumlandırma ve üslubu uyguluyor mu? Başka alanların açılışını, genel sloganları ve aynı kelimeleri tekrarlıyor mu? Kayıtsız ürün iddiası ekledin mi? Uymayan metni düzelt. Marka kaynağını bir özet bilgisi gibi geçiştirme; ilgili editoryal kurallarını uygula. Bu kontrol listesini, iç değerlendirmeyi veya marka belgesini yanıta yazma; yalnız görev için istenen son metni/JSON sonucunu ver.\n";
}
